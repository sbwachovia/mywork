import { Component, OnInit } from '@angular/core';
import { AccessoriesAppService } from './../shared/services/Accessories/accessories-app.service'
import { AccessoryRootObject, Response, ProductVOList, CompatibleDevices, AccountDevices, ChildSkus } from './../shared/models/accessories-app-model'
import { AccessorySaveQuoteRootObject, AccessoryQuoteResponse } from './../shared/models/accessories-app-model'
import { ComparisonContainer, ProposedCharges } from './../shared/models/overview-app-model'
import { SpinnerUtils } from "../shared/utils/spinner-utils";
import { FormsModule } from "@angular/forms";
import { InteractionService } from "./../shared/services/data-interaction/interaction-service";
import { OverviewAppService } from "./../shared/services/Overview/overview-app.service";
import { StateCacheService } from "./../shared/services/data-interaction/state-cache.service";
import { DataScrollerModule } from 'primeng/primeng';


@Component({
    selector: 'accessories-app',
    templateUrl: './accessories-app.component.html',
    styleUrls: ['./accessories-app.component.css']
})
export class AccessoriesAppComponent implements OnInit {
    accessoryJSON: AccessoryRootObject;
    accessoryList: ProductVOList[];
    compatibleDevices: CompatibleDevices[];
    accountDevices: AccountDevices[];
    proposedCharge: ProposedCharges;
    brands: string[];
    categorys: string[];
    workItem: string = "Compatible With";

    selAccessorySorId: string;

    counter: number = 1;
    start: number = 1;
    end: number = 20;
    offset: number = 10;

    //hardcoding for now initial values
    accoundDevices = [{
        "deviceProductId": "dev40266",
        "deviceProductName": "DROID 2 "
    }, {
        "deviceProductId": "dev40140",
        "deviceProductName": "DROID 2 Global "
    }, {
        "deviceProductId": "dev40392",
        "deviceProductName": "DROID 3 "
    }];


    constructor(private _accessoriesAppService: AccessoriesAppService,
        private interactionService: InteractionService,
        private _overviewAppService: OverviewAppService,
        private _cacheService: StateCacheService) { }



    ngOnInit(): void {

        // this.showSpinner(true);

        // this._accessoriesAppService.
        //     fetchAccessories("accessLevel=PRODUCT&start=1&end=20").
        //     subscribe((res) => {
        //         this.accessoryJSON = res;
        //         console.log("I am here -> AccessoriesAppComponent: ", this.accessoryJSON.response[0].childSkus[0].brand);
        //         this.accessoryList = this.accessoryJSON.response;
        //         this.showSpinner(false);
        //     },
        //     error => {
        //         console.log(error);
        //         this.showSpinner(false);
        //     });
    }

    private showSpinner(show: boolean) {
        SpinnerUtils.showSpinner('#main-menu-tabs', show);
    }


    onScroll(event) {
        console.log('scroll event', event);
    }


    //   loadDataSrini(event) {
    //     console.log("inside loadData event");

    //     //initialize
    //     if (this.accessoryList.length == 0) {
    //       //this.carService.getCarsSmall().then(cars => this.cars = cars);
    //       let i = 1;
    //       do {
    //             let c: Response = { productId: i+"", 
    //             productDisplayName: "productDisplayName",
    //             prdActiveFlag: 1,
    //             prdDisplaySeq: "prdDisplaySeq",
    //             prdLastModifiedTs: "prdLastModifiedTs",
    //             prdShowcaseInd: 1,
    //             childSkus: [],
    //             siteId: "siteId",
    //             channel: "channel"
    //         }
    //         this.accessoryList.push(c);
    //         i = i + 1;
    //       }
    //       while (i < 10);
    //     }
    //     // //in real application, newArray should be loaded from a remote datasource
    //     else {
    //       let latestArraySize = this.accessoryList.length;
    //       let newArray = this.accessoryList.slice(0, 3);
    //       for (let i = 0; i < newArray.length; i++) {
    //             let c: Response = { productId: latestArraySize+i+"", 
    //             productDisplayName: "productDisplayName",
    //             prdActiveFlag: 1,
    //             prdDisplaySeq: "prdDisplaySeq",
    //             prdLastModifiedTs: "prdLastModifiedTs",
    //             prdShowcaseInd: 1,
    //             childSkus: [],
    //             siteId: "siteId",
    //             channel: "channel"
    //         };
    //         this.accessoryList.push(c);
    //       }
    //       // this.msgs = [];
    //       // this.msgs.push({ severity: 'info', summary: 'Data Loaded', detail: 'Between ' + event.first + ' and ' + (event.first + event.rows) });
    //     }
    //   }

    loadData(event) {
        if (this.counter > 8) {
            this.showSpinner(false);
            return;
        }

        this.showSpinner(true);
        //initialize First time call
        if (!this.accessoryList) {
            this._accessoriesAppService.
                fetchAccessories("accessLevel=PRODUCT&start=1&end=20").
                subscribe((res) => {
                    this.accessoryJSON = res;
                    this.accessoryList = this.accessoryJSON.response.productVOList;
                    this.brands = this.accessoryJSON.response.accessoryFacetedVO.brands;
                    this.categorys = this.accessoryJSON.response.accessoryFacetedVO.categories;
                    this.compatibleDevices = this.accessoryJSON.response.accessoryFacetedVO.compatibleDevices;
                    if (this.accessoryJSON.response.accessoryFacetedVO.accountDevices) {
                        this.accountDevices = this.accessoryJSON.response.accessoryFacetedVO.accountDevices;
                    }
                    this.accountDevices.push({ "deviceProductId": "MORE", "deviceProductName": "More..." });
                    this.showSpinner(false);
                },
                error => {
                    console.log(error);
                    this.showSpinner(false);
                });
        }
        //in real application, newArray should be loaded from a remote datasource
        else {
            this.showSpinner(true);
            this.counter = this.counter + 1;
            this.start = this.end + 1;
            this.end = this.end + this.offset;
            let query = "accessLevel=PRODUCT&start=" + this.start + "&end=" + this.end;
            console.log("Iteration: ", this.counter);
            this._accessoriesAppService.
                fetchAccessories(query).
                subscribe((res) => {
                    this.accessoryJSON = res;
                    for (let i = 0; i < this.accessoryJSON.response.productVOList.length; i++) {
                        this.accessoryList.push(this.accessoryJSON.response.productVOList[i]);
                        this.brands = this.accessoryJSON.response.accessoryFacetedVO.brands;
                        this.categorys = this.accessoryJSON.response.accessoryFacetedVO.categories;
                        this.accountDevices = this.accessoryJSON.response.accessoryFacetedVO.accountDevices;
                        this.accountDevices.push({ "deviceProductId": "MORE", "deviceProductName": "More..." });


                    }
                    console.log("accessoryJSON Lenth: ", this.accessoryJSON.response.productVOList.length);

                    this.showSpinner(false);
                },
                error => {
                    console.log(error);
                    this.showSpinner(false);
                });



        }
    }

    onBrandChange($event) {
        console.log("Brand Selected: ", $event.srcElement.value);
        this.counter = 1;
        let query = "accessLevel=PRODUCT&start=1&end=20&filterSelectionSequence=BRAND&brand=" + $event.srcElement.value;
        this.showSpinner(true);
        this._accessoriesAppService.
            fetchAccessories(query).
            subscribe((res) => {
                this.accessoryJSON = res;
                this.accessoryList = this.accessoryJSON.response.productVOList;
                this.brands = this.accessoryJSON.response.accessoryFacetedVO.brands;
                this.categorys = this.accessoryJSON.response.accessoryFacetedVO.categories;
                this.compatibleDevices = this.accessoryJSON.response.accessoryFacetedVO.compatibleDevices;
                this.showSpinner(false);
            },
            error => {
                console.log(error);
                this.showSpinner(false);
            });
    }

    onCategoryChange($event) {
        console.log("Category Selected: ", $event.srcElement.value);
        this.counter = 1;
        let query = "accessLevel=PRODUCT&start=1&end=20&filterSelectionSequence=CATEGORY&categoryName=" + $event.srcElement.value;
        this.showSpinner(true);
        this._accessoriesAppService.
            fetchAccessories(query).
            subscribe((res) => {
                this.accessoryJSON = res;
                this.accessoryList = this.accessoryJSON.response.productVOList;
                this.brands = this.accessoryJSON.response.accessoryFacetedVO.brands;
                this.categorys = this.accessoryJSON.response.accessoryFacetedVO.categories;
                this.compatibleDevices = this.accessoryJSON.response.accessoryFacetedVO.compatibleDevices;
                this.accountDevices = this.accessoryJSON.response.accessoryFacetedVO.accountDevices;
                this.accountDevices.push({ "deviceProductId": "MORE", "deviceProductName": "More..." });

                this.showSpinner(false);
            },
            error => {
                console.log(error);
                this.showSpinner(false);
            });
    }


    onWorksWithChange($event) {
        console.log("Works with Selected: ", $event.srcElement.value);
        this.counter = 1;
        //let deviceProductId = this.compatibleDevices.values($event.srcElement.value);
        console.log("index: ", this.compatibleDevices);
        let query = "accessLevel=PRODUCT&start=1&end=20&filterSelectionSequence=DEVICE&deviceProductId=" + $event.srcElement.value;
        this.showSpinner(true);
        this._accessoriesAppService.
            fetchAccessories(query).
            subscribe((res) => {
                this.accessoryJSON = res;
                this.accessoryList = this.accessoryJSON.response.productVOList;
                this.brands = this.accessoryJSON.response.accessoryFacetedVO.brands;
                this.categorys = this.accessoryJSON.response.accessoryFacetedVO.categories;
                this.compatibleDevices = this.accessoryJSON.response.accessoryFacetedVO.compatibleDevices;
                this.accountDevices = this.accessoryJSON.response.accessoryFacetedVO.accountDevices;
                this.accountDevices = this.accessoryJSON.response.accessoryFacetedVO.accountDevices;
                this.accountDevices.push({ "deviceProductId": "MORE", "deviceProductName": "More..." });

                console.log()
                this.showSpinner(false);
            },
            error => {
                console.log(error);
                this.showSpinner(false);
            });
    }

    handleSelectAccessory(selProduct: ProductVOList) {
        console.log("Selected SOR: ", selProduct.childSkus[0].sorId);
        this.selAccessorySorId = selProduct.childSkus[0].sorId;

    }

    onAccessoryQuote($event) {
        console.log("Hitting Add to Quote in Accessories");
        let query = "qty=1&sorId=" + this.selAccessorySorId; //add the SOR ID of the selected Accessory
        this._accessoriesAppService.addToQuoteAccessories(query).subscribe((res) => {
            this.proposedCharge = res.response.quoteComparisonContainerVO.proposedCharges;
            let comparisonContainer = res.response.quoteComparisonContainerVO;
            this._cacheService.comparisonContainer = res.response.quoteComparisonContainerVO;
            this.interactionService.publishComparisonContainer(comparisonContainer);
            this._cacheService.productVOList = res.response.productVOList;
            this._cacheService.proposedCharges = res.response.quoteComparisonContainerVO.proposedCharges;
            // console.log("AccessoryQuoteResponse sku: ", this._cacheService.productVOList[0].childSkus[0].brand);
            console.log("Accessory Quote Response dueToday Price: ", this.proposedCharge.dueToday.price.formattedPrice);
        })

    }

    getMoreAccessories() {
        console.log("More Accessories: ");
        console.log("Counter: ", this.counter);

        if (this.counter < 20) {
            this.counter = this.counter + 1;
            console.log("Counter: ", this.counter);
            return true;
        }
        else
            return false;

    }

}
