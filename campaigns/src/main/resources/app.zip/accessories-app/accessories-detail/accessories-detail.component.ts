import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { AccessoryRootObject, ProductVOList, ChildSkus } from './../../shared/models/accessories-app-model';
import { StringUtils } from "../../shared/utils/string-utils";
import { FormsModule } from "@angular/forms";


@Component({
  selector: 'accessories-detail',
  templateUrl: './accessories-detail.component.html',
  styleUrls: ['./accessories-detail.component.css']
})
export class AccessoriesDetailComponent implements OnInit {

  @Input() inputAccessory: ProductVOList;
  @Output() select: EventEmitter<ProductVOList> = new EventEmitter<ProductVOList>();

  displayAccessory: ChildSkus;
  showDiscount: boolean = true;
  selSKU: ChildSkus;
  skuColors: string[];
  selSKUColor: string;
  selSKUQty: string;

  ngOnInit() {
    this.selSKU = this.inputAccessory.childSkus[0];

    this.selSKUColor = this.selSKU.colorName;
    this.selSKUQty = "1";

    if (this.inputAccessory.childSkus[0].discountedPrice == 0) {
      this.showDiscount = false;
    }
    this.skuColors = this.inputAccessory.childSkus.map(sku => sku.colorName);
    if (this.skuColors) {
      this.skuColors = this.skuColors.filter((item, i, arr) => {
        return arr.indexOf(item) == i;
      });
      this.skuColors = this.skuColors.filter(color => {
        if (!StringUtils.isNullOrEmpty(color)) return color;
      });
      // this.onColorChange();
    }
    console.log("skuColors: ", this.skuColors);
    console.log("selSKUColor: ", this.selSKUColor);

  }

  onColorChange() {
    console.log("onColorChange method: ", this.selSKUColor, this.selSKUQty);
    if (this.selSKUColor) {
      this.selectSKU();
    }
  }
  selectSKU() {
    if (this.selSKUColor && this.selSKUQty) {
      this.selSKU = this.inputAccessory.childSkus.find(childSku => {
        return ((childSku.colorName === this.selSKUColor))
          // && (childSku.quantityAvailable >= this.selSKUQty))
      });
    }
    console.log("Selected SKU: ", this.selSKU);
  }

  handleTileClick(selectedSKU: ChildSkus) {
    if (selectedSKU) {
      let selDevice = Object.assign({}, this.inputAccessory)
      selDevice.childSkus = [selectedSKU];
      selDevice.selected = true;

      this.select.emit(selDevice);
    }
  }

  getStrikeLine() {
    if (!this.showDiscount)
      return "none";
  }
}


