import { NgModule } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";
import { AccessoriesAppComponent } from "./accessories-app.component";
import { AccessoriesAppService } from "./../shared/services/Accessories/accessories-app.service";
import { AccessoriesDetailComponent } from './accessories-detail/accessories-detail.component';
import { CommonModule } from '@angular/common';
import { DataScrollerModule } from 'primeng/primeng';
import {FormsModule} from "@angular/forms";


const moduleRoutes: Routes = [
    {
        path: '',
        component: AccessoriesAppComponent
    },
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(moduleRoutes),
        FormsModule,
        DataScrollerModule
    ],
    declarations: [
        AccessoriesAppComponent,
        AccessoriesDetailComponent
    ],
    providers: [
        AccessoriesAppService
    ],
})
export class AccessoriesAppModule {

}
