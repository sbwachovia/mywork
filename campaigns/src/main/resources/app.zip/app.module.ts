import { CustomReuseStrategy } from './CustomReuseStrategy';
import { RouteReuseStrategy } from '@angular/router';
import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';

import {OverviewAppModule} from "./overview-app/overview-app.module";
import {DeviceAppModule} from "./device-app/device-app.module";
import {PlanAppModule} from "./plan-app/plan-app.module";
import {AccessoriesAppModule} from "./accessories-app/accessories-app.module";
import {TradeinAppModule} from "./tradein-app/tradein-app.module";
import {RecycleAppModule} from "./recycle-app/recycle-app.module";
import {AppRoutingModule} from './app-routing.module';

import {AppComponent} from './app.component';
import {AppHeaderComponent} from "./home/header/app-header.component";
import {AppSidebarComponent} from "./home/sidebar/sidebar.component";
import {PageNotFoundComponent} from "./home/exception/not-found.component";
import {TabMenuComponent} from "./shared/components/tab-menu/tab-menu.component";

import {DialogModule,
        EditorModule,
        SharedModule,
        GrowlModule,
        TabMenuModule,
        DataScrollerModule } from 'primeng/primeng';

import {OverviewAppService} from "./shared/services/Overview/overview-app.service";
import {HttpService} from "./shared/services/http-client/http.service";
import {InteractionService} from "./shared/services/data-interaction/interaction-service";
import {StateCacheService} from "./shared/services/data-interaction/state-cache.service";
import {DeviceAppService} from "./shared/services/device/device-app.service";
import {AccessoriesAppService} from "./shared/services/Accessories/accessories-app.service";
import {PlanAppService} from "./shared/services/plan/plan-app.service";
import {TradeinAppService} from "./shared/services/tradein/tradein-app.service";
import {NBSService} from "./shared/services/NBS/nbs.service";
import {ErrorHandlingService} from "./shared/services/error-handling/error-handling.service";
import {NextBillCycleComponent} from "./NBS/nbs.component";

import {DevicesCacheService} from "./device-app/devices-cache.service";
import {EmailComponent} from "./Email/email.component";

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        //OverviewAppModule,
        //DeviceAppModule,
        //PlanAppModule,
        //AccessoriesAppModule,
        //TradeinAppModule,
        //RecycleAppModule,
        AppRoutingModule,
        TabMenuModule,
        EditorModule,
        DialogModule,
        SharedModule,
        DataScrollerModule,
        GrowlModule
    ],
    declarations: [
        AppComponent,
        AppHeaderComponent,
        PageNotFoundComponent,
        AppSidebarComponent,
        TabMenuComponent,
        NextBillCycleComponent,
        EmailComponent
    ],
    providers: [
        HttpService,
        OverviewAppService,
        InteractionService,
        DeviceAppService,
        PlanAppService,
        TradeinAppService,
        StateCacheService,
        NBSService,
        DevicesCacheService,
        AccessoriesAppService,
        ErrorHandlingService,
        {provide: RouteReuseStrategy, useClass: CustomReuseStrategy}
    ],
    bootstrap: [
        AppComponent
    ]
})
export class AppModule
{

}
