import {Component, Input, OnDestroy, OnInit, trigger, transition, style, animate} from "@angular/core";
import {NBSService} from "../shared/services/NBS/nbs.service";
import {NBSRoot, OneTimeMonthChargeVO, OtcPlanAcctLevelChargesVO, MonthlyAccountLevelChargesVO, MonthChargeVO} from "../shared/models/nbs-model";
import { Subscription } from "rxjs";
import {SpinnerUtils} from "../shared/utils/spinner-utils";

@Component({
    selector: 'app-nbs',
    animations: [
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({transform: 'translateX(100%)', opacity: 0}),
          animate('500ms', style({transform: 'translateX(0)', opacity: 1}))
        ]),
        transition(':leave', [
          style({transform: 'translateX(0)', opacity: 1}),
          animate('500ms', style({transform: 'translateX(100%)', opacity: 0}))
        ])
      ]
    )
  ],
    templateUrl: './nbs.component.html',
    styles: ['.vzrf { overflow-y:scroll; overflow-x: hidden;height:800px; width:1000px;}']

})
export class NextBillCycleComponent implements OnInit, OnDestroy
{

    accountNum: string;
    thisMonthDate: string;
    nextMonthDate: string;
    thisMonthTotal: string;
    nextMonthTotal: string;
    acctOtcThisMnthPrice: string;
    oneTimeMonthCharge: OneTimeMonthChargeVO[];
    otcPlanAcctLevelCharges: OtcPlanAcctLevelChargesVO[];
    monthlyAccountLevelCharges: MonthlyAccountLevelChargesVO[];
    acctRecurThisMnthPrice: string;
    acctRecurNextMnthPrice: string;
    monthCharge: MonthChargeVO[];
    surChargeNextMonth: string;
    surChargeThisMonth: string;
    taxNextMonth: string;
    taxNewMonth: string;
    loadingSubscription: Subscription;
    toggleMonthyCharge = {};
    toggleOneTimeCharge = {};
    showDetailsOneTimePlanAndAccount: boolean = false;
    showDetailsMontlyPlanAndAccount: boolean = false;
    constructor(private _nbsService: NBSService){

    }

    ngOnInit(){

    }

    initNBSService(){
        console.log("NBS Service called")
        this.showSpinner(true);
        let nbsRequest = {
            mtn: 8013884930,
        };
        this.loadingSubscription = this._nbsService.fetchNextBillSummary(nbsRequest)
            .subscribe((jsonResp) => {
                let nbsJson: NBSRoot = jsonResp;
                this.thisMonthDate = nbsJson.response.thisMonthDate;
                this.nextMonthDate = nbsJson.response.nextMonthDate;
                this.thisMonthTotal = nbsJson.response.thisMonthTotal;
                this.nextMonthTotal = nbsJson.response.nextMonthTotal;
                this.oneTimeMonthCharge = nbsJson.response.oneTimeMonthCharge;
                this.accountNum = nbsJson.response.accountNum;
                this.acctOtcThisMnthPrice = nbsJson.response.acctOtcThisMnth.formattedPrice;
                this.otcPlanAcctLevelCharges = nbsJson.response.otcPlanAcctLevelCharges;
                this.monthlyAccountLevelCharges = nbsJson.response.monthlyAccountLevelCharges;
                this.acctRecurThisMnthPrice = nbsJson.response.acctRecurThisMnth.formattedPrice;
                this.acctRecurNextMnthPrice = nbsJson.response.acctRecurNextMnth.formattedPrice;
                this.monthCharge = nbsJson.response.monthCharge;
                this.surChargeNextMonth = nbsJson.response.surChargeNextMonth.formattedPrice;
                this.surChargeThisMonth = nbsJson.response.surChargeThisMonth.formattedPrice;
                this.taxNextMonth = nbsJson.response.taxNextMonth.formattedPrice;
                this.taxNewMonth = nbsJson.response.taxNewMonth.formattedPrice;
                
                this.showSpinner(false);
        },
            error => {
                console.log(error);
                this.showSpinner(false);
            });
    }

     ngOnDestroy() {
        if(this.loadingSubscription)
        {
            this.loadingSubscription.unsubscribe();
        }
    }

    private showSpinner(show: boolean)
    {
        SpinnerUtils.showSpinner('#main-menu-tabs', show);
    }


}
