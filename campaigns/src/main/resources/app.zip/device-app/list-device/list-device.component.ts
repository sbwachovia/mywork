import {Component, Input, OnInit, Output, EventEmitter} from '@angular/core';
import {LineSummaryList} from "../../shared/models/overview-app-model";



@Component({
    selector: 'list-device',
    templateUrl: './list-device.component.html',
    styleUrls: ['./list-device.component.css']
})
export class ListDeviceComponent implements OnInit
{
    @Input() line: LineSummaryList;
    oldLine: LineSummaryList;

    @Output() change: EventEmitter<LineSummaryList> = new EventEmitter<LineSummaryList>();
    @Output() reset: EventEmitter<LineSummaryList> = new EventEmitter<LineSummaryList>();


    ngOnInit()
    {
        this.oldLine = Object.assign({}, this.line);
    }

    onReset()
    {
        if(this.line)
        {
            this.reset.emit(this.line);
        }
    }

    handleChange(lineCB: HTMLInputElement)
    {
        this.line.checked = lineCB.checked;
        if(this.line)
        {
            this.change.emit(this.line);
        }
    }

    copy(toLine: LineSummaryList, fromLine: LineSummaryList)
    {
        toLine.mtn = fromLine.mtn;
        toLine.userName = fromLine.userName;
        toLine.deviceDisplayName = fromLine.deviceDisplayName;
    }

}
