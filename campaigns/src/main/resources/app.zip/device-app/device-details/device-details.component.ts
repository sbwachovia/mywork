import {Component, Input, OnInit, Output, EventEmitter} from '@angular/core';
import {DialogModule} from 'primeng/primeng';
import {ButtonModule} from 'primeng/primeng';
import {DropdownModule} from 'primeng/primeng';
import {DeviceRootObject, CategoryVOList, ChildProducts, ChildSkus} from './../../shared/models/device-app-model';
import {StringUtils} from "../../shared/utils/string-utils";


@Component({
    selector: 'device-details',
    templateUrl: './device-details.component.html',
    styleUrls: ['./device-details.component.css']
})
export class DeviceDetailsComponent extends OnInit
{
    @Input() device: ChildProducts;
    @Output() select: EventEmitter<ChildProducts> = new EventEmitter<ChildProducts>();

    selSKU: ChildSkus;
    skuCapacities: string[];
    selSKUCapacity: string;
    skuColors: string[];
    selSKUColor: string;


    ngOnInit()
    {
        this.skuCapacities = this.device.childSkus.map(sku => sku.capacity);
        if(this.skuCapacities)
        {
            this.skuCapacities = this.skuCapacities.filter((item, i, arr) => {
                return arr.indexOf(item) == i;
            });
            this.skuCapacities = this.skuCapacities.filter(capacity => {
                if(!StringUtils.isNullOrEmpty(capacity)) return capacity;
            });

            this.selSKUCapacity = this.skuCapacities[0];
        }

        this.onCapacityChange();
    }

    onCapacityChange()
    {
        if(this.selSKUCapacity)
        {
            this.skuColors = this.device.childSkus.filter(sku => {
                if(sku.capacity === this.selSKUCapacity) return sku;
            }).map(sku => sku.deviceColor);

            this.skuColors = this.skuColors.filter((color, i, arr) => {
                return arr.indexOf(color) == i;
            });
            this.skuColors = this.skuColors.filter(color => {
                if(!StringUtils.isNullOrEmpty(color)) return color;
            });

            this.selSKUColor = this.skuColors[0];

            this.setSelectedSKU();
        }
    }

    onColorChange()
    {
        if(this.selSKUColor)
        {
            this.setSelectedSKU();
        }
    }

    private setSelectedSKU()
    {
        if(this.selSKUCapacity && this.selSKUColor)
        {
            this.selSKU = this.device.childSkus.find(childSku => {
                return ((childSku.deviceColor === this.selSKUColor)
                            && (childSku.capacity === this.selSKUCapacity));
            });
        }
    }

    handleTileClick(selectedSKU: ChildSkus)
    {
        if(selectedSKU)
        {
            this.device.childSkus.map(sku => {
                sku.selected = false;
                return sku;
            });

            selectedSKU.selected = true;
            this.device.selected = true;
            this.select.emit(this.device);
        }
    }

}
