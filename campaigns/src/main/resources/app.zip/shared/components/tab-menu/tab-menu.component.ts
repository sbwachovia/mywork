import {Component, Input, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {InteractionService} from "../../services/data-interaction/interaction-service";


@Component({
    selector: 'tab-menu',
    templateUrl: 'tab-menu.component.html',
    styleUrls: ['./tab-menu.component.css']
})
export class TabMenuComponent implements OnInit
{
    @Input() menuItems: MenuItem[];

    constructor(private interactionService: InteractionService, private router: Router)
    {
        interactionService.menuSubject$.subscribe(selMenuItem => {
                let menuItem: MenuItem = this.menuItems.find(item => item.routerLink == selMenuItem.routerLink);
                this.activateTab(menuItem);
            }
        );
    }

    ngOnInit(): void {
        let pathname = window.location.pathname;
        if(pathname == '/')
        {
            pathname = '/overview'
        }
        let menuItem: MenuItem = this.menuItems.find(item => item.routerLink == pathname);
        if(menuItem)
        {
            this.activateTab(menuItem);
        }
    }

    activateTab(menuItem: MenuItem) {
        this.deactivateAllTabs();
        menuItem.active = true;
    }

    deactivateAllTabs() {
        this.menuItems.map(item => item.active = false);
    }

    navigateRoute(path) {
        this.router.navigate([path]);
    }

}

export interface MenuItem {
    label?: string;
    routerLink?: any;
    active?: boolean;
}
