import {Injectable} from '@angular/core';
import {Subject, Observable} from 'rxjs';
import {HttpService} from './../http-client/http.service'
import {DeviceRootObject} from './../../models/device-app-model'
import * as appConstants from '../../config/app.constants';

@Injectable()
export class DeviceAppService
{
    constructor(private _httpService: HttpService) {}

    fetchDevices(req: DeviceSearch): Observable<DeviceRootObject>
    {
        let paramsStr = 'categoryName=' + req.categoryName
                        //+ '&brand='
                        + '&searchText=' + req.searchText
                        + '&start=' + req.start
                        + '&end=' + req.end;
        return this._httpService.get(appConstants.DEVICE_LOOKUP_ROUTE_PATH + '?' + paramsStr);
    }

    fetchRecommendDevices(params: any): Observable<DeviceRootObject>
    {
        let paramsStr = 'mtn=' + params.mtn;
        return this._httpService.get(appConstants.DEVICE_RECOMEND_LOOKUP_ROUTE_PATH + '?' + paramsStr);
    }


    deviceChange(req: DeviceRequest): Observable<any>
    {
        return this._httpService.post('/quote-service/quote/performDeviceAction', req);
    }

    fetchAvailableCategories(): Observable<any>
    {
        return this._httpService.get('/quote-service/catalog/facetedSearchData');
    }

}

export class DeviceSearch
{
    categoryName: string;
    searchText: string;
    start: number;
    end: number;
}

export class DeviceRequest
{
    action: string;
    inputData: LineDevice[];
}
export class LineDevice
{
    mld: string;
    itemCode?: string;
    isNewLine?: boolean;
    isCPE?: boolean;
    selTransType?: string;
    resetAction?: string;
    buyoutAmt?: number;
}



