import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { HttpService } from './../http-client/http.service'
import { AccessoryRootObject, AccessorySaveQuoteRootObject } from './../../models/accessories-app-model'
import * as appConstants from '../../config/app.constants';

@Injectable()
export class AccessoriesAppService {

  constructor(private _httpService: HttpService) { 

  }

  fetchAccessories(query: string):Observable <AccessoryRootObject> {
    return this._httpService.get(appConstants.ACCESSORIES_LOOKUP_ROUTE_PATH + '?' +query);
  }

  addToQuoteAccessories(query: string):Observable <AccessorySaveQuoteRootObject> {
    return this._httpService.get(appConstants.QUOTE_ACCESSORIES_LOOKUP_ROUTE_PATH+ '?' +query)
  }

}
