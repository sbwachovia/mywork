import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { HttpService } from './../http-client/http.service';
import { PlanRoot } from './../../models/plan-app-model';
import * as appConstants from '../../config/app.constants';

@Injectable()
export class PlanAppService {

  constructor(private _httpService: HttpService) {

  }

  fetchPlans(query: any): Observable<PlanRoot> {
    return this._httpService.get(appConstants.PLAN_LOOKUP_ROUTE_PATH);
  }


  moveToShare(query: string): Observable<PlanRoot> {
    return this._httpService.get(appConstants.PLAN_MOVE_TO_SHARE + query);
  }

}
