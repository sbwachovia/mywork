import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { HttpService } from './../http-client/http.service'
import { TradeInRoot } from './../../models/tradein-app-model'
import * as appConstants from '../../config/app.constants';

@Injectable()
export class TradeinAppService {

  constructor(private _httpService: HttpService) { 

  }

  fetchTradein(params: any):Observable <TradeInRoot> {
    let paramsStr = 'mtn=' + params.mtn;
    return this._httpService.get(appConstants.TRADEIN_LOOKUP_ROUTE_PATH + '?' + paramsStr);  
  }

}
