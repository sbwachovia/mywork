import {Injectable, OnInit} from "@angular/core";
import { Headers, Http, Response, RequestOptions } from "@angular/http";

import { Observable } from "rxjs";
import 'rxjs/add/operator/map';
import * as appConstants from '../../config/app.constants';



@Injectable()
export class HttpService
{
    private baseURL: string;

    constructor(private http: Http) {
        this.setupBaseURL();
    }

    private setupBaseURL() {
         if (process.env.ENV === 'production') {
             this.baseURL = appConstants.PROD_BASE_REST_URL;
         } else {
             this.baseURL = appConstants.DEV_BASE_REST_URL;
         }
    }

    public get(_url: string): Observable<any>
    {
        let _endPointURL = this.baseURL + _url;
        console.log("URL: " + _endPointURL);

        let httpReqHeaders = new Headers({ 'Content-Type': 'application/json' });
        httpReqHeaders.append('Authorization', 'Basic TU9UUk4xOjIwMTNUZXN0aW5n');
        httpReqHeaders.append('clientid', 'quote-retail');

        let options = new RequestOptions({ headers: httpReqHeaders });

        return this.http
            .get(_endPointURL, options)
            .timeout(60000)
            .map((response: Response) => response.json())
            .do((data) => console.log(JSON.stringify(data)))
            .catch(this.handleError);
    }


    public post(_url: string, params: any): Observable<any>
    {
        let _endPointURL = this.baseURL + _url;
        let _queryStr = JSON.stringify(params);
        console.log(_endPointURL);

        let httpReqHeaders = new Headers({ 'Content-Type': 'application/json' });
        httpReqHeaders.append('Authorization', 'Basic TU9UUk4xOjIwMTNUZXN0aW5n');
        httpReqHeaders.append('clientid', 'quote-retail');

        let options = new RequestOptions({ headers: httpReqHeaders });

        return this.http
            .post(_endPointURL, _queryStr, options)
            .timeout(60000)
            .map((response: Response) => response.json())
            .do((data) => console.log(JSON.stringify(data)))
            .catch(this.handleError);
    }


    /**
     * TODO : remote logging
     * @param error
     * @returns {ErrorObservable}
     */
    private handleError(error: Response | any)
    {
        let errMsg: string;
        if (error instanceof Response)
        {
            const body = JSON.stringify(error);
            errMsg = `statusCode : ${error.status} | statusText : ${error.statusText || ''} | detail : ${body}`;
        }
        else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

}
