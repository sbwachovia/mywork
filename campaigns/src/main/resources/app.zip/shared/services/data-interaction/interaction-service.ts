import {Injectable} from "@angular/core";
import {Subject, BehaviorSubject} from "rxjs";
import {MenuItem} from "../../components/tab-menu/tab-menu.component";
import {OverviewRoot, OverviewPlanVO, LineSummaryList, ComparisonContainer} from './../../models/overview-app-model';
import {PlanRoot} from './../../models/plan-app-model'



@Injectable()
export class InteractionService
{
    private loadingSubject = new BehaviorSubject(false)
    loadingSubject$ = this.loadingSubject.asObservable();
    publishLoading(isLoading: boolean)
    {
        this.loadingSubject.next(isLoading);
    }    

    private planSubject = new Subject<OverviewPlanVO>();
    planSubject$ = this.planSubject.asObservable();
    publishPlan(plan: OverviewPlanVO)
    {
        this.planSubject.next(plan);
    }


    private menuSubject = new Subject<MenuItem>();
    menuSubject$ = this.menuSubject.asObservable();
    publishMenuItem(menuItem:MenuItem)
    {
        this.menuSubject.next(menuItem);
    }


    private overviewRootSubject = new Subject<OverviewRoot>();
    overviewRootSubject$ = this.overviewRootSubject.asObservable();
    publishOverviewRoot(overviewRoot:OverviewRoot)
    {
        this.overviewRootSubject.next(overviewRoot);
    }
     private statusSubject = new Subject<any>();
    statusSubject$ = this.statusSubject.asObservable();
    statusPlan(statusObj)
    {
        this.statusSubject.next(statusObj);
    }

    
    private comparisonContainerSubject = new Subject<ComparisonContainer>();
    comparisonContainerSubject$ = this.comparisonContainerSubject.asObservable();
    publishComparisonContainer(comparisonContainer: any)
    {
        this.comparisonContainerSubject.next(comparisonContainer);
    }


    private planAppSubject = new Subject<PlanRoot>();
    planAppSubject$ = this.planAppSubject.asObservable();
    publishPlanApp(planApp: PlanRoot)
    {
        this.planAppSubject.next(planApp);
    }


    private lineSummaryListSubject = new Subject<LineSummaryList[]>();
    lineSummaryListSubject$ = this.lineSummaryListSubject.asObservable();
    publishLineSummary(lineSummary: LineSummaryList[])
    {
        this.lineSummaryListSubject.next(lineSummary);
    }


}
