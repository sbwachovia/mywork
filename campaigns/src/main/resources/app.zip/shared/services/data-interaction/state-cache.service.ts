import { Injectable } from "@angular/core";
import { OverviewRoot, OverviewAccountVO, LineSummaryList, OverviewPlanVO, ComparisonContainer, ProductPlanList, ProposedCharges } from "../../models/overview-app-model";
import { TransitionQueryParams } from "../../models/app-models";
import { PlanRoot } from './../../models/plan-app-model';
import { ChildProducts } from "../../models/device-app-model";
import { ProductVOList } from "../../models/accessories-app-model";



@Injectable()
export class StateCacheService {
    overviewJson: OverviewRoot;

    accountTileList: OverviewAccountVO[];
    currentlyShowingLessAccountTiles: boolean;
    currentlyHidingAccountTilesDiv: boolean;

    linePlanSummaryList: ProductPlanList;
    accountPlanSummaryList: ProductPlanList;
    toolTipStateOnLineSummary: boolean;

    lineSummaryList: LineSummaryList[];

    transitionQueryParams: TransitionQueryParams;
    comparisonContainer: ComparisonContainer;


    plans: PlanRoot;


    // Devices: START.
    devices: ChildProducts[];
    recommendedDevices: ChildProducts[];
    availableCategories: string[];
    // Devices: START.


    //Accessories: START
    productVOList: ProductVOList[];
    proposedCharges: ProposedCharges;
    //Accessories: End

}

