import {Injectable} from '@angular/core';
import {Subject, Observable} from 'rxjs';
import {HttpService} from './../http-client/http.service';
import {NBSRoot} from './../../models/nbs-model'
import * as appConstants from '../../config/app.constants';

@Injectable()
export class NBSService{

    constructor(private _httpService: HttpService){}   

    fetchNextBillSummary(params: any): Observable<NBSRoot>
    {
        let paramsStr = 'mtn=' + params.mtn;
        return this._httpService.get(appConstants.NBS_LOOKUP_ROUTE_PATH + '?' + paramsStr);           
    }
}