/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { OverviewAppService } from './overview-app.service';

describe('OverviewAppService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OverviewAppService]
    });
  });

  it('should ...', inject([OverviewAppService], (service: OverviewAppService) => {
    expect(service).toBeTruthy();
  }));
});
