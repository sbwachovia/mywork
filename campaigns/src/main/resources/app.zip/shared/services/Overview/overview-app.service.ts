import { ProceedToOrderRootObject } from './../../models/app-models';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpService} from './../http-client/http.service'
import {OverviewRoot} from './../../models/overview-app-model'
import * as appConstants from '../../config/app.constants';


@Injectable()
export class OverviewAppService
{
    constructor(private _httpService: HttpService){}

    fetchAccountSummary(params: any): Observable<OverviewRoot>
    {
        let paramsStr = 'mtn=' + params.mtn;
        return this._httpService.get(appConstants.OVERVIEW_LOOKUP_ROUTE_PATH + '?' + paramsStr);
            //.delay(1000); // Uncomment this to see the init load spinner.
    }

    updatePlan(query: string): Observable<OverviewRoot>
    {
        return this._httpService.get(appConstants.PLAN_UPDATE_ROUTE_PATH + '?' + query)
    }

    fetchQuoteDetails(params: any): Observable<ProceedToOrderRootObject>
    {
        let paramsStr = 'action=' + params.action;
        return this._httpService.get(appConstants.PROCEED_TO_ORDER_URL + '?' + paramsStr)
    }



    resetQuote(): Observable<any>
    {
        return this._httpService.get(appConstants.RESET_QUOTE)
    }

     emailQuote(query: string): Observable<any> 
     {
    return this._httpService.get(appConstants.EMIAL_QUOTE + query);
     }


     updateTap(action: string): Observable<OverviewRoot> {
         return this._httpService.get(appConstants.TAP_UPDATE_ROUTE_PATH + action)
     }

}
