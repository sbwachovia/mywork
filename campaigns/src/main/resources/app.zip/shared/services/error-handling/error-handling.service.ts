import {Injectable} from '@angular/core';
import {Subject} from 'rxjs/Subject';


@Injectable()
export class ErrorHandlingService {

  public errorMessageSubject$ = new Subject<string>();

  public setErrorMessage(msg: string) {
    this.errorMessageSubject$.next(msg);
  }

}
