'use strict';

/**
 * REST service base URL for PROD
 * @type {string}
 */
export const PROD_BASE_REST_URL = 'https://telestore-prj3.vzwcorp.com';

/**
 * DEV URL --> point to your local or prj
 * @type {string}
 */
export const DEV_BASE_REST_URL = 'http://localhost:3000';
// export const DEV_BASE_REST_URL = 'http://10.74.43.61:5401';
// export const DEV_BASE_REST_URL = 'http://10.177.213.170:7005';



/**
 * http call request timeout
 * @type {number}
 */
export const HTTP_REQUEST_TIMEOUT = 60000;  // in milli seconds


/** overview lookup **/
export const OVERVIEW_LOOKUP_ROUTE_PATH = "/quote-service/quote/overview";

/** devices lookup **/
export const DEVICE_LOOKUP_ROUTE_PATH = "/quote-service/catalog/getPostpayGroupDevices";
export const DEVICE_RECOMEND_LOOKUP_ROUTE_PATH = "/quote-service/quote/recommend";

/** Plan lookup **/
//export const PLAN_LOOKUP_ROUTE_PATH = "/quote-service/quote/plan";
export const PLAN_LOOKUP_ROUTE_PATH = "/quote-service/plan/planPage";


export const ACCESSORIES_LOOKUP_ROUTE_PATH = "/quote-service/catalog/getGroupedAccessories";
export const QUOTE_ACCESSORIES_LOOKUP_ROUTE_PATH = "/quote-service/accessories/addAccessoryToCart";

export const PLAN_UPDATE_ROUTE_PATH =  "/quote-service/plan/addSharePlanToCart";

export const PROCEED_TO_ORDER_URL = "/quote-service/quote/proceedOptions";

/** Plan Move to Share **/
export const PLAN_MOVE_TO_SHARE = "/quote-service/plan/addToShare?mldSeq=";

export const NBS_LOOKUP_ROUTE_PATH = "/quote-service/quote/nbs";

/** Reset Quote **/
export const RESET_QUOTE = "/quote-service/quote/proceedOptions?action=CLEAR_CURRENT_QUOTE";

/** Email Quote */
export const EMIAL_QUOTE = "/quote-service/quote/proceedOptions?action=SEND_EMAIL&retailId=1234&email=";

/** Update Tap */
export const TAP_UPDATE_ROUTE_PATH =  "/quote-service/plan/updateTapToCart?action=";


export const TRADEIN_LOOKUP_ROUTE_PATH = "/quote-service/quote/deviceTradeIn";
