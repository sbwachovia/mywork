

export class SpinnerUtils
{

    public static showSpinner(selector: string, show: boolean)
    {
        let spinner = <HTMLDivElement>document.querySelector('.spinner');
        if (show)
        {
            let elmToCover = <HTMLDivElement>document.querySelector(selector);
            if(elmToCover)
            {
                let elmToCoverStyle = window.getComputedStyle(elmToCover, null);

                let obj = this.getOffset(elmToCover);

                spinner.style.top = obj.top + 'px';
                spinner.style.left = obj.left + 'px';
                spinner.style.width = elmToCoverStyle.width;
                spinner.style.height = elmToCoverStyle.height;
                spinner.querySelector('span').style.lineHeight = elmToCoverStyle.height;
            }

            spinner.style.display = 'block';
        }
        else
        {
            spinner.style.display = 'none';
        }
    }


    static getOffsetSum(elem) {
        var top=0, left=0
        while(elem) {
            top = top + parseInt(elem.offsetTop)
            left = left + parseInt(elem.offsetLeft)
            elem = elem.offsetParent
        }
        return {top: top, left: left};
    }


    static getOffsetRect(elem) {
        var box = elem.getBoundingClientRect()

        var body = document.body
        var docElem = document.documentElement

        var scrollTop = window.pageYOffset || docElem.scrollTop || body.scrollTop
        var scrollLeft = window.pageXOffset || docElem.scrollLeft || body.scrollLeft

        var clientTop = docElem.clientTop || body.clientTop || 0
        var clientLeft = docElem.clientLeft || body.clientLeft || 0

        var top  = box.top +  scrollTop - clientTop
        var left = box.left + scrollLeft - clientLeft

        return { top: Math.round(top), left: Math.round(left) };
    }


    static getOffset(elem: HTMLElement) {
        if (elem.getBoundingClientRect) {
            return this.getOffsetRect(elem);
        } else {
            return this.getOffsetSum(elem);
        }
    }

}
