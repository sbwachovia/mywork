


export class StringUtils
{
    public static isNullOrEmpty(str: string)
    {
        if(!str || (str && ((str.trim() === '') || (str.trim().toUpperCase() === 'NULL'))))
        {
            return true;
        }
        return false;
    }
}
