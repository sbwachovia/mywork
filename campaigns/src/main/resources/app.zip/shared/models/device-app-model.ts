export class ChildSkus {
    siteId: string;
    billToAccountFlag?: any;
    brand: string;
    capacity: string;
    channel: string;
    colorCssStyle: string;
    daccId: string;
    deviceColor: string;
    devicePaymentEligible: string;
    deviceType: string;
    dpContractTerm: number;
    dpFirstMonthPrice: number;
    dpPercentage: number;
    dpRemainingMonthPrice?: any;
    dpUpgOptionCode: string;
    edgeFullRetailPrice: number;
    fullRetailPrice?: any;
    imageName: string;
    oneYrPrice: number;
    organicRecycleValue: number;
    prepayPrice: number;
    skuActiveFlag: number;
    skuDescrition: string;
    skuDisplayName: string;
    skuDisplaySeq?: any;
    skuId: string;
    skuLastModifiedTs: number;
    skuSequenceNum: number;
    skuShowcaseInd: number;
    sorId: string;
    twoYrPrice: number;
    techSpecification?: any;
    inTheBox?: any;
    longDescription?: any;
    longDescriptionB2b?: any;
    features?: any;
    discountedPrice?: any;
    averageRatings?: any;
    numberOfReviews?: any;

    selected?: boolean;
}

export class ChildProducts {
    productId?: string;
    productDisplayName?: string;
    prdActiveFlag?: number;
    prdDisplaySeq?: any;
    prdLastModifiedTs?: number;
    prdShowcaseInd?: number;
    childSkus?: ChildSkus[];
    siteId?: string;
    channel?: string;

    selected?: boolean;
}

export class CategoryVOList {
    categoryId: string;
    categoryName: string;
    parentCategory?: any;
    siteId: string;
    channel: string;
    childProducts: ChildProducts[];
}

export class Response {
    categoryVOList: CategoryVOList[];
}

export class DeviceRootObject {
    response: Response;
    error?: any;
    status: string;
    success: boolean;
    duration: number;
}
