export class TradeInRoot{
    response: TradeInResponse;
    error?: any;
    status: string;
    success: boolean;
    duration: number;
}

export class TradeInResponse{
    tradeInSummaryVO : TradeInSummaryVO[];
    tradeInContainerUpdated: string;
}

export class TradeInSummaryVO{
    tradeInDeviceId: string;
    tradeInValue: number;
    tradeInDeviceSku:string;
    tradeInDeviceMtn: string;
    capacity: string;
    imageName: string;
}
