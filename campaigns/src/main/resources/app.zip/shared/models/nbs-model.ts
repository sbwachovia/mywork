export class NBSRoot{
    response: NBSResponse;
    error?: any;
    status: string;
    success: boolean;
    duration: number;
}

export class NBSResponse{
    nextMonthTotal: string;
    thisMonthDate: string;
    nextMonthDate: string;
    surChargeNextMonth: SurChargeNextMonth;
    surChargeThisMonth: SurChargeThisMonth;
    taxNextMonth: TaxNextMonth;
    taxNewMonth: TaxNewMonth;
    acctRecurThisMnth: AcctRecurThisMnth;
    acctRecurNextMnth: AcctRecurThisMnth;
    acctOtcThisMnth: AcctOtcThisMnth;
    acctOtcNextMnth: AcctOtcNextMnth;
    monthCharge: MonthChargeVO[];
    oneTimeMonthCharge: OneTimeMonthChargeVO[];
    monthlyAccountLevelCharges: MonthlyAccountLevelChargesVO[];
    otcPlanAcctLevelCharges: OtcPlanAcctLevelChargesVO[];
    thisMonthTotal: string;
    creditHeader :string;
    prevBalance: string;
    pmtReceived: string;
    totalCreditAmt: TotalCreditAmt;
    accountNum: string;
    billCycleStartDate: string;
    currentDate: string;
}

export class SurChargeNextMonth{
    cents: string;
    formattedPrice: string;
    value: string;  
    dollar: string;
}

export class SurChargeThisMonth{
    cents: string;
    formattedPrice: string;
    value: string;  
    dollar: string;
}

export class TaxNextMonth{
    cents: string;    
    value: string;
    formattedPrice : string;
    dollar: string;
}

export class TaxNewMonth {
     cents: string;
     formattedPrice : string;
     value : number;
     dollar : string;
}

export class AcctRecurNextMnth{
     cents: string;
     formattedPrice : string;
     value : number;
     dollar : string;
}

export class AcctRecurThisMnth{
     cents: string;
     formattedPrice : string;
     value : number;
     dollar : string;
}

export class AcctOtcThisMnth {
     cents: string;
     formattedPrice : string;
     value : number;
     dollar : string;
}

export class AcctOtcNextMnth{
     cents: string;
     formattedPrice : string;
     value : number;
     dollar : string;
}

export class MonthChargeVO{
    thisMonthCharge: string;
    nickName: string;
    description: string;
    previousMonthCharge: string;
    mtn: string;
    formattedMtn: string;
    chargeDetails1:ChargeDetails[];
    nextMonthCharge:string;
}

export class ChargeDetails{
    promo3Desc: string;
    thisMonthCharge: string;
    promo2Discount : string;
    promo1Desc : string;
    itemType : boolean;
    overageDesc : string;
    chargeEffectiveFormattedDate : string;
    description : string;
    formattedDate : string;
    promo1Discount : string;
    promo3Discount : string;
    chargeEffectiveDate : string;
    chargeEndFormattedDate : string;
    promo2Desc : string;
    nextMonthCharge : string;
    note: string;
    chargeType: string;
    expiryDate: string;
}

export class OneTimeMonthChargeVO{
    thisMonthCharge: string;
    nickName: string;
    description: string;
    previousMonthCharge: string;
    mtn: string;
    formattedMtn: string;
    chargeDetails1:ChargeDetails[];
    nextMonthCharge:string;
}

export class MonthlyAccountLevelChargesVO{
    promo3Desc: string;
    thisMonthCharge: string;
    promo2Discount : string;
    promo1Desc : string;
    itemType : boolean;
    overageDesc : string;
    chargeEffectiveFormattedDate : string;
    description : string;
    formattedDate : string;
    promo1Discount : string;
    promo3Discount : string;
    chargeEffectiveDate : string;
    chargeEndFormattedDate : string;
    promo2Desc : string;
    nextMonthCharge : string;
    note: string;
    chargeType: string;
    expiryDate: string;
}

export class OtcPlanAcctLevelChargesVO{
    promo3Desc: string;
    thisMonthCharge: string;
    promo2Discount : string;
    promo1Desc : string;
    itemType : boolean;
    overageDesc : string;
    chargeEffectiveFormattedDate : string;
    description : string;
    formattedDate : string;
    promo1Discount : string;
    promo3Discount : string;
    chargeEffectiveDate : string;
    chargeEndFormattedDate : string;
    promo2Desc : string;
    nextMonthCharge : string;
    note: string;
    chargeType: string;
    expiryDate: string;
}

export class TotalCreditAmt{
     cents: string;
     formattedPrice : string;
     value : number;
     dollar : string;
}

