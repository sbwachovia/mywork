
export class Charges {
    deviceCharge: number;
    planCharge: number;
    featureCharge: number;
    accessoryCharge: number;
    discount: number;
    taxAndSurcharge: number;
}

export class TransitionQueryParams {
    env?: string;
    uswin?: string;
    salesRepid?: string;
    location?: string;
    mtn?: string;
} 



export class ProceedToOrderResponse {
    cartId: string;
    quoteId: string;
    message: string;
}

export class ProceedToOrderRootObject {
    response: ProceedToOrderResponse;
    message?: any;
    error?: any;
    status: string;
    success: boolean;
    duration: number;
}



