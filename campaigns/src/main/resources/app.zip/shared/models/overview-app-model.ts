
export class OverviewAccountVO {
    tileName: string;
    tileDescription: string;
    tileValue: string;
    tileType: string;
    tileStyle: string;
    enabled: boolean;
}

export class AccountSummaryLabels {
    safetyMode: string;
    price: string;
    mexicoAndCanadaRoaming: string;
    dataBoost: string;
    carryOverData: string;
    mexicoAndCanadaLongDist: string;
}

export class AccountSummary {
    accountTileList: OverviewAccountVO[];
    accountSummaryLabels: AccountSummaryLabels;
}

export class AccountContainer {
    accountSummary: AccountSummary;
    accountContainerUpdated: string;
    tapEnabled: boolean;
    tapChargeAmount: number;
    albrestricted: boolean;
    apprestricted: boolean;
}

export class OverviewPlanVO {
    planId: string;
    planSize?: any;
    planTotalData: string;
    planUnitOfMeasure: string;
    planCharge: number;
    planChargePerGB: string;
    planCarryOverData?: any;
    safetyMode?: any;
    dataBoost?: any;
    planLabel: string;
    imageName: string;
    displayName: string;
    collectionCode?: any;
    currentPlan: boolean;
    recommendedPlan: boolean;
    selected: boolean;
    productId: string;
    prdDisplaySequence?: number;
    mexicoCanadaRoaming?: any;
    mexicoCanadaLongDist?: any;
}

export class ProductPlanList {
    productId: string;
    planList: OverviewPlanVO[];
    defaultProduct: boolean;
}

export class PlanContainer {
    productPlanList: ProductPlanList[];
    mtn?: any;
    lines: number;
    currentPlanDetails?: any;
    defaultCollectionCode?: any;
    planContainerUpdated: string;
    name?: any;
}

export class FeatureContainer {
    featureInContainerUpdated: string;
}

export class Price {
    formattedPrice: string;
    cents: number;
    dollar: number;
    value: number;
}

export class QuotePrice {
    price: Price;
    discount: Price;
    beforeDiscount: Price;
}

export class LineAccessCharge{
    displayPrice: string;
    retailPrice: string;
    details: LineAccessDetails[]
}

export class LineAccessDetails{
    desc: string;
    price: string;
}

export class QuoteCharges {
    lineAccessCharge: LineAccessCharge;
    devicePayment: QuotePrice;
    equipmentProtectionCharge: QuotePrice;
    planCharge: QuotePrice;
    featureCharge: QuotePrice;
    upgradeCharge: QuotePrice;
    buyOutCharge: QuotePrice;
    tradeInCharge: QuotePrice;
    accessoryCharge: QuotePrice;
    upgradeFee: QuotePrice;
    montlyInstallment: QuotePrice;
    downPayment: QuotePrice;
    otherCharge: QuotePrice;
    dueToday: QuotePrice;
    dueMonthly: QuotePrice;
    totalCharge: QuotePrice;
}

export class LineSummaryList {
    currentLineCharges?: QuoteCharges;
    proposedLineCharges?: QuoteCharges;
    deviceId?: string;
    mtn: string;
    deviceType?: string;
    brand?: string;
    deviceDisplayName?: string;
    userName?: string;
    deviceLabel?: any;
    deviceImage?: string;
    planImage?: string;
    deviceDisplayLink?: any;
    mldSequence?: string;
    deviceDaccId?: string;
    upgradeOptions?: string[];
    moveToShare?: boolean;
    updated?: boolean;
    planDisplayName?: string;
    buyoutAmount?: QuotePrice;
    enableBuyout?: boolean;

    checked?: boolean; // Now it may have been labled as updated
    isResetEnabled?: any; // Now it may have been labled as ??
    isNewLine?: boolean;
    isModified?: boolean;
    selectedUpgradeOption?: string;
    showToolTip?: boolean;
    toolTipType?: string;
}

export class DeviceContainer {
    lineSummaryList: LineSummaryList[];
    deviceContainerUpdated: string;
}



export class TradeInContainer {
    tradeInSummaryVO: any[];
    tradeInContainerUpdated: string;
}

export class CurrentCharges {
    deviceCharge: number;
    planCharge: number;
    featureCharge: number;
    accessoryCharge: number;
    discount: number;
    taxAndSurcharge: number;
    total: number;
    sumTotal: number;
}


export class ProposedCharges {
    deviceCharge: QuotePrice;
    planCharge: QuotePrice;
    lineAccessCharge: QuotePrice;
    featureCharge: QuotePrice;
    accessoryCharge: QuotePrice;
    discount: QuotePrice;
    taxAndSurcharge: QuotePrice;
    dueToday: QuotePrice;
    dueMonthly: QuotePrice;
    total: QuotePrice;
    isupdated: boolean;
}

export class ComparisonContainer {
    currentCharges?: any;
    proposedChargesList?: any;
    existingCharges?: ProposedCharges;
    proposedCharges: ProposedCharges;
}

export class Account {
    accountContainer: AccountContainer;
    planContainer: PlanContainer;
    featureContainer: FeatureContainer;
    deviceContainer: DeviceContainer;
    tradeInContainer: TradeInContainer;
    comparisonContainer: ComparisonContainer;
}

export class EligibilityVO {
    billToAccountAmount?: any;
    btaAmount: string;
    dpeligible: boolean;
    dprequiredDownPaymentAmount: number;
    dpspendingLimit?: any;
    dpspendingLimitRemainingAmount?: any;
}

export class Response {
    navigationContainer?: any;
    accounts: Account[];
    commonInfoContainer?: any;
    modified: boolean;
    eligibilityVO: EligibilityVO;
}

export class OverviewRoot {
    response: Response;
    error?: any;
    status: string;
    success: boolean;
    duration: number;
}

