import {ComparisonContainer} from './overview-app-model';


export interface CurrentChargesInfo {
    lineAccessCharge: string;
    devicePayment: string;
    equipmentProtectionCharge?: any;
    planCharge: string;
    featureCharge?: any;
    totalCharge: string;
    otherCharge?: any;
    upgradeCharge?: any;
    buyOutCharge?: any;
    tradeInCharge?: any;
    promoCharge?: any;
}

export interface LineList {
    currentChargesInfo: CurrentChargesInfo;
    proposedChargesInfo?: any;
    deviceId: string;
    mtn: string;
    deviceType: string;
    brand?: any;
    deviceDisplayName: string;
    userName: string;
    deviceLabel?: any;
    planImage: string;
    deviceDisplayLink?: any;
    mldSequence?: any;
    deviceDaccId: string;
    moveToShare: boolean;
    updated: boolean;
    planDisplayName?: any;
}

export interface Account {
    lineList: LineList[];
    numberOfLines: number;
    totalPlanCharge: number;
}

export interface CurrentChargesInfo2 {
    lineAccessCharge: string;
    devicePayment: string;
    equipmentProtectionCharge?: any;
    planCharge: string;
    featureCharge?: any;
    totalCharge: string;
    otherCharge?: any;
    upgradeCharge?: any;
    buyOutCharge?: any;
    tradeInCharge?: any;
    promoCharge?: any;
}

export interface LineList2 {
    currentChargesInfo: CurrentChargesInfo2;
    proposedChargesInfo?: any;
    deviceId: string;
    mtn: string;
    deviceType: string;
    brand?: any;
    deviceDisplayName: string;
    userName: string;
    deviceLabel?: any;
    planImage: string;
    deviceDisplayLink?: any;
    mldSequence?: any;
    deviceDaccId: string;
    moveToShare: boolean;
    updated: boolean;
    planDisplayName: string;
}

export interface Individual {
    lineList: LineList2[];
    numberOfLines: number;
    totalPlanCharge?: any;
}

export interface PlanList {
    planId: string;
    planSize?: any;
    planTotalData: string;
    planUnitOfMeasure: string;
    planCharge: number;
    planChargePerGB: string;
    planCarryOverData?: any;
    safetyMode?: any;
    dataBoost?: any;
    planLabel: string;
    imageName: string;
    displayName: string;
    collectionCode?: any;
    currentPlan: boolean;
    recommendedPlan: boolean;
    selected: boolean;
    productId: string;
    prdDisplaySequence: number;
    productDisplayName?: any;
    mexicoCanadaRoaming?: any;
    mexicoCanadaLongDist?: any;
}

export interface ProductPlanList {
    productId: string;
    productName: string;
    planList: PlanList[];
    defaultProduct: boolean;
}

export interface CurrentPlanDetails {
    planId: string;
    planSize?: any;
    planTotalData: string;
    planUnitOfMeasure: string;
    planCharge: number;
    planChargePerGB: string;
    planCarryOverData?: any;
    safetyMode?: any;
    dataBoost?: any;
    planLabel: string;
    imageName: string;
    displayName: string;
    collectionCode?: any;
    currentPlan: boolean;
    recommendedPlan: boolean;
    selected: boolean;
    productId: string;
    prdDisplaySequence?: any;
    productDisplayName?: any;
    mexicoCanadaRoaming?: any;
    mexicoCanadaLongDist?: any;
}

export interface ShowCasePlans {
    productPlanList: ProductPlanList[];
    mtn: string;
    lines: number;
    currentPlanDetails: CurrentPlanDetails;
    defaultCollectionCode?: any;
    planContainerUpdated: string;
    name: string;
}

export interface Response {
    account: Account;
    individual: Individual;
    showCasePlans: ShowCasePlans;
    comparisonContainerVO: ComparisonContainer;
}

export interface PlanRoot {
    response: Response;
    message?: any;
    error?: any;
    status: string;
    success: boolean;
    duration: number;
}

