import { ComparisonContainer, ProposedCharges } from './overview-app-model';

export class ChildSkus {
	averageRatings: number;
	brand: string;
	channel: string;
	colorCssStyle: string;
	colorName: string;
	discountedPrice: number;
	features: string;
	fullRetailPrice: number;
	imageName: string;
	inTheBox?: any;
	numberOfReviews: string;
	prdDisplaySeq?: any;
	prdShowcaseInd?: any;
	productId?: any;
	productName?: any;
	skuActiveFlag: number;
	skuDisplaySeq?: any;
	skuId: string;
	skuName: string;
	skuSequenceNum: number;
	skuShowcaseInd: number;
	sorId: string;
	techSpecification?: any;
	quantityAvailable: string;
	availabilityFlow: string;
	available: string;
	shipByDate?: any;
	imageUrl: string;
	
}

export class ProductVOList {
	productId: string;
	productDisplayName: string;
	prdActiveFlag: number;
	prdDisplaySeq?: any;
	prdLastModifiedTs: number;
	prdShowcaseInd: number;
	childSkus: ChildSkus[];
	siteId: string;
	channel: string;
	selected: boolean;
}

export class CompatibleDevices {
	deviceProductId: string;
	deviceProductName: string;
}

export class AccessoryFacetedVO {
	accountDevices: AccountDevices[];
	compatibleDevices: CompatibleDevices[];
	brands: string[];
	categories: string[];
}

export class AccountDevices {
	deviceProductId: string;
	deviceProductName: string;
}

export class Response {
	productVOList: ProductVOList[];
	accessoryFacetedVO: AccessoryFacetedVO;
	endOfResults: number;
	filterSelectionSequence: string;
}

export class AccessoryRootObject {
	response: Response;
	message?: any;
	error?: any;
	status: string;
	success: number;
	duration: number;
}


export class AccessorySaveQuoteRootObject {
	response: AccessoryQuoteResponse;
	message?: any;
	error?: any;
	status: string;
	success: number;
	duration: number;
}


export class AccessoryQuoteResponse {
	productVOList: ProductVOList[];
	quoteComparisonContainerVO: ComparisonContainer;
}
