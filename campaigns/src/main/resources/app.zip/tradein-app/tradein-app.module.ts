import {NgModule} from '@angular/core';
import {Routes, RouterModule} from "@angular/router";
import {TradeinAppComponent} from "./tradein-app.component";
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";


const moduleRoutes: Routes = [
    {
        path: '',
        component: TradeinAppComponent
    },
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        RouterModule.forChild(moduleRoutes)
    ],
    declarations: [
        TradeinAppComponent
    ],
    providers: [],
})
export class TradeinAppModule
{

}
