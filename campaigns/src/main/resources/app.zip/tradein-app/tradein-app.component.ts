import {Component} from '@angular/core';
import { Subscription } from "rxjs";
import {TradeinAppService} from "../shared/services/tradein/tradein-app.service";
import {TradeInRoot, TradeInSummaryVO} from "../shared/models/tradein-app-model";
import {SpinnerUtils} from "../shared/utils/spinner-utils";

@Component({
    selector: 'tradein-app',
    templateUrl: './tradein-app.component.html'
})
export class TradeinAppComponent
{
    constructor(private _tradeInService: TradeinAppService){
    }

    loadingSubscription: Subscription;
    tradeInSummaryVO: TradeInSummaryVO[];
    ngOnInit() {
        this.initTradeInService();
    }

    initTradeInService(){
        console.log("Tradein Service called")
        
        let nbsRequest = {
            mtn: 8013884930,
        };
        this.loadingSubscription = this._tradeInService.fetchTradein(nbsRequest)
            .subscribe((jsonResp) => {
                let tradeInJson: TradeInRoot = jsonResp;
                if(tradeInJson.response){
                    this.tradeInSummaryVO =  tradeInJson.response.tradeInSummaryVO;
                }     
                this.showSpinner(false);
        },
            error => {
                console.log(error);
                this.showSpinner(false);
                alert("Error occured:"+ error);
            });
    }

     ngOnDestroy() {
        if(this.loadingSubscription)
        {
            this.loadingSubscription.unsubscribe();
        }
    }

     private showSpinner(show: boolean)
    {
        SpinnerUtils.showSpinner('#main-menu-tabs', show);
    }


}
