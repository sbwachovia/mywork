import { Component, Input, OnDestroy, OnInit, trigger, transition, style, animate } from "@angular/core";
import { Subscription } from "rxjs";

import { OverviewAppService } from "../shared/services/Overview/overview-app.service";





@Component({
    selector: 'app-email',
    templateUrl: './email.component.html',
    styles: ['.vzrf { overflow-y:scroll; overflow-x: hidden;height:800px; width:900px;}', '.emailPopup{width: 800px;}', '.emailWidth{width: 400px !important;}', '.button{min-width: 165px !important; width: auto !important;}']

})
export class EmailComponent implements OnInit {

    email: string;

    constructor(
        private _overviewAppService: OverviewAppService,)
    {}



    ngOnInit() {

    }

    emailQuote() {

        console.log("hello");
        this._overviewAppService.emailQuote(this.email)
            .subscribe((jsonResp) => {
                console.log("Here is the email !!" + jsonResp.message);
                console.log("here is your email", this.email)

            },
            error => {
                console.log(error);
                console.log("error in reset !!" + error);
            });

    }

}