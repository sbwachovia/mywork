import {Component} from '@angular/core';


@Component({
    selector: 'recycle-app',
    templateUrl: './recycle-app.component.html'
})
export class RecycleAppComponent
{

}
