import {NgModule} from '@angular/core';
import {Routes, RouterModule} from "@angular/router";
import {RecycleAppComponent} from "./recycle-app.component";



const moduleRoutes: Routes = [
    {
        path: '',
        component: RecycleAppComponent
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(moduleRoutes)
    ],
    declarations: [
        RecycleAppComponent
    ],
    providers: [],
})
export class RecycleAppModule
{

}
