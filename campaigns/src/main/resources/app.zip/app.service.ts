import {Injectable} from "@angular/core";
import {HttpService} from "./shared/services/http-client/http.service";
import {Observable, Subject} from "rxjs";

@Injectable()
export class AppService
{
    constructor(private httpService: HttpService){}

    fetchAllData(): Observable<any>
    {
        let url = "http://localhost:3000/accountTileList/"
        //let url = 'http://10.74.43.61:5401/quote-service/quote/overview?mtn=8013884930';
        //url = 'http://localhost:3000/builds/';
        return this.httpService.get(url, );
    }

    fetchAccounts(): Observable<any>
    {
        let url = 'app/accountTileList';
        return this.httpService.get(url);
    }

    fetchPlans(): Observable<any>
    {
        let url = 'app/planSummaryList';
        return this.httpService.get(url);
    }

    fetchLines(): Observable<any>
    {
        let url = 'app/lineSummaryList';
        return this.httpService.get(url);
    }

    fetchDevices(): Observable<any>
    {
        let url = 'app/devicesList';
        return this.httpService.get(url);
    }

}
