import { Component, Input } from '@angular/core';
import { InteractionService } from "../../shared/services/data-interaction/interaction-service";
import { OverviewAppService } from "../../shared/services/Overview/overview-app.service";
import { StateCacheService } from "../../shared/services/data-interaction/state-cache.service";


@Component({
    selector: 'plan-Shared',
    templateUrl: './plan-shared.component.html'
})
export class PlanSharedComponent {
    @Input() accountPlans;
    @Input() plansList;
    @Input() planCharge;
    @Input() planName;


    ngOnInit() {


    }

}
