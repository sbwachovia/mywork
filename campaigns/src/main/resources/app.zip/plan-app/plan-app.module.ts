import {NgModule} from '@angular/core';
import { CustomReuseStrategy } from './../CustomReuseStrategy';
import { Routes, RouterModule,RouteReuseStrategy } from "@angular/router";
import {PlanAppComponent} from "./plan-app.component";
import {PlanLineLevelComponent} from "./plan-lineLevel/plan-lineLevel.component";
import {PlanSharedComponent} from "./plan-shared/plan-shared.component";
import { CommonModule } from '@angular/common';
import { PlanAppService } from './../shared/services/plan/plan-app.service';



const moduleRoutes: Routes = [
    {
        path: '',
        component: PlanAppComponent
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(moduleRoutes),
        CommonModule
    ],
    declarations: [
        PlanAppComponent,
        PlanSharedComponent,
        PlanLineLevelComponent
    ],
    providers: [
        PlanAppService,
        {provide: RouteReuseStrategy, useClass: CustomReuseStrategy}
    ],
})
export class PlanAppModule
{

}
