import {Injectable} from "@angular/core";
import {PlanRoot} from "../shared/models/plan-app-model";


@Injectable()
export class PlansCacheService
{
    plans: PlanRoot;
}

