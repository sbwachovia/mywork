import {Component, Input} from '@angular/core';
import {InteractionService} from "../../shared/services/data-interaction/interaction-service";
import {PlanAppService} from "../../shared/services/plan/plan-app.service";
import {StateCacheService} from "../../shared/services/data-interaction/state-cache.service";
import { PlanRoot, LineList, ProductPlanList, CurrentPlanDetails } from './../../shared/models/plan-app-model';
import {CurrentCharges, ProposedCharges, ComparisonContainer} from '../../shared/models/overview-app-model';
import {SpinnerUtils} from "../../shared/utils/spinner-utils";





@Component({
    selector: 'plan-lineLevel',
    templateUrl: './plan-lineLevel.component.html'
})
export class PlanLineLevelComponent
{

    @Input() individualPlan;
    @Input() planCharge;
    @Input() planName;

    isProcessing: boolean = false;

     constructor(private interactionService: InteractionService,
                private _planAppService: PlanAppService,
                private _cacheService: StateCacheService,) {}   


     moveToShare(mldSequence: string) {
         this.showSpinner(true);
         if (!this.isProcessing) {
             this.isProcessing = true;
             console.log('mldSequence -- ' + mldSequence);

             this._planAppService.moveToShare(mldSequence).subscribe((jsonResp) => {
                 console.log("moveToShare Listener !!");

                 let jsonData: PlanRoot = jsonResp;
                 let comparisonContainer: ComparisonContainer = jsonResp.response.comparisonContainerVO;
                 this.interactionService.publishPlanApp(jsonData);
                 console.log("Listener in moveToShare !!" + comparisonContainer);

                 this.isProcessing = false;
                 this.showSpinner(false);

                 this._cacheService.comparisonContainer = comparisonContainer;
                 this.interactionService.publishComparisonContainer(comparisonContainer);
             },
                 error => {
                     console.log(error);
                     this.isProcessing = false;
                     this.showSpinner(false);
                     console.log("error in moveToShare !!" + error);
                 });
         }
        }
        




     private showSpinner(show: boolean) {
         SpinnerUtils.showSpinner('#main-menu-tabs', show);
     }

}
