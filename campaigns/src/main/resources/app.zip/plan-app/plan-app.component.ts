import { Component, OnInit } from '@angular/core';
import { Subscription } from "rxjs";

import { PlanAppService } from './../shared/services/plan/plan-app.service';
import { PlanRoot, LineList, ProductPlanList, CurrentPlanDetails } from './../shared/models/plan-app-model';
import {SpinnerUtils} from "../shared/utils/spinner-utils";
import {StateCacheService} from "../shared/services/data-interaction/state-cache.service";
import {InteractionService} from "../shared/services/data-interaction/interaction-service";



@Component({
    selector: 'plan-app',
    templateUrl: './plan-app.component.html'
})
export class PlanAppComponent implements OnInit
{
    plans: PlanRoot;
    accountPlansList: LineList[];
    individualPlansList: LineList[];
    showCasePlansList: ProductPlanList[];
    currentPlanDetails: CurrentPlanDetails;
    currentPlanName: String;
    currentPlanCharge: number;
    noOfLines: number;
    subscription: Subscription;
    hideIndividualLines: boolean = true;


    constructor(
        private _planAppService: PlanAppService,
        private _plansCacheService: StateCacheService,
        private _interactionService: InteractionService,
    ) {
        this.subscription = _interactionService.planAppSubject$.subscribe(planApp => {
            this._plansCacheService.plans = planApp;
            this.plans = planApp;
                this.loadPlans();
                this.showSpinner(false);
        });
    }


    ngOnInit(): void {
        this.plans = this._plansCacheService.plans;

        if (this.plans) {
            this.loadPlans();
        } else {
            this.showSpinner(true);
            this._planAppService.fetchPlans(null).
                subscribe((response) => {
                    this.plans = response;
                    this._plansCacheService.plans = response;
                    this.loadPlans();
                    this.showSpinner(false);
                },
                error => {
                    console.log(error);
                    this.showSpinner(false);
                });
        }
    }

     loadPlans() {
         this.noOfLines = this.plans.response.account.numberOfLines;
         this.accountPlansList = this.plans.response.account.lineList;
         this.individualPlansList = this.plans.response.individual.lineList;
         this.showCasePlansList = this.plans.response.showCasePlans.productPlanList;
         this.currentPlanDetails = this.plans.response.showCasePlans.currentPlanDetails;

         if (this.currentPlanDetails) {
             this.currentPlanName = this.currentPlanDetails.displayName;
             this.currentPlanCharge = this.currentPlanDetails.planCharge;
         }

         this.hideIndividualLines = true;
         if (this.individualPlansList.length > 0) {
             this.hideIndividualLines = false;
         }
     }

    private showSpinner(show: boolean)
    {
        SpinnerUtils.showSpinner('#main-menu-tabs', show);
    }


}
