import {Component, Input} from '@angular/core';

import {AccountSummary} from "../../shared/models/overview-app-model";
import {InteractionService} from "../../shared/services/data-interaction/interaction-service";

@Component({
    selector: 'overview-accountTile',
    templateUrl: './overview-accountTile.component.html',
     styleUrls: ['./overview-accountTile.component.css']
})
export class OverviewAccountTileComponent
{
    @Input() accountTile;

    constructor(private interactionService: InteractionService){}

    clickListener(value: string)
    {
        // let plan:AccountSummary =
        // {
        //     tileName: "Upgrades",
        //     tileDescription: "Lines are eligible",
        //     tileValue: "3",
        //     tileType: "Type1",
        //     tileStyle: value,
        //     enabled: true
        // };

        // this.interactionService.publish(plan);
    }


}
