import { Component, OnInit } from '@angular/core';
import {OverviewRoot, OverviewAccountVO, LineSummaryList, OverviewPlanVO, ComparisonContainer} from "../shared/models/overview-app-model";
import { StateCacheService } from "../shared/services/data-interaction/state-cache.service";
import { InteractionService } from "../shared/services/data-interaction/interaction-service";
import {OverviewAppService} from "../shared/services/Overview/overview-app.service";
import { Subscription } from "rxjs/Subscription";
import { GrowlModule, Message } from 'primeng/primeng';
import { Router } from "@angular/router";
import { MenuItem } from "../shared/components/tab-menu/tab-menu.component";
import {LineDevice, DeviceRequest, DeviceAppService} from "../shared/services/device/device-app.service";
import {SpinnerUtils} from "../shared/utils/spinner-utils";



@Component({
    selector: 'overview-app',
    templateUrl: './overview-app.component.html',
})
export class OverviewAppComponent implements OnInit
{
    accountTileList: OverviewAccountVO[];
    lineSummaryList: LineSummaryList[];
    accountRemnantTileList: any = [];
    planSummaryList: OverviewPlanVO[];
    selectedCost: any = { "planCharge": "", "planColor": "black", "planStatusIcon": "" };
    show: boolean = true;
    isTapEnabled: boolean = false;
    tapChargeAmount: number;
    isrestricted: boolean = true;
    totalDueToday;
    selectedPlan: any = {};
    planClick: number;
    loadingSubscription: Subscription;
    isLoading2: boolean = true;
    showSingleLinePlans: boolean = false;
    msgs: any[];
    isPlanRestricted: boolean = true;
    showTile: boolean = true;
    showMoreLessAccountTileText: string;
    showAccessory: boolean = false;
    accessoryPrice: string = "$0.00";
    isTapProcessing: boolean = false;


    constructor(
        private _cacheService: StateCacheService,
        private _interactionService: InteractionService,
        private router: Router,
        private _deviceService: DeviceAppService,
        private _overviewAppService: OverviewAppService,


    ) {
        _interactionService.overviewRootSubject$.subscribe(lineSummary => {
            this.load();
        });

        _interactionService.lineSummaryListSubject$.subscribe(overviewRoot => {
            this.loadLineSummary();
        });

        this.loadingSubscription = _interactionService.loadingSubject$.subscribe(status => {
            this.isLoading2 = status;
        });
    }

    ngOnInit() {
        this.load();
    }

    ngOnDestroy() {
        //this.subscription.unsubscribe();
        this.loadingSubscription.unsubscribe();
    }

    loadLineSummary()
    {
        this.lineSummaryList = this._cacheService.lineSummaryList;

        if (this.lineSummaryList && this.lineSummaryList.length > 0) {
            this.totalDueToday = this.lineSummaryList
                .map(line => {
                    return (line.currentLineCharges.dueToday.price.value) ? Number(line.currentLineCharges.dueToday.price.value) : 0;
                })
                .reduce((current, next) => {
                    return current + next;
                });
        }
    }

    showMoreOrLessTiles() {
        if (this._cacheService.currentlyShowingLessAccountTiles) {
            this.accountTileList = this._cacheService.accountTileList;//show all times
            this.showMoreLessAccountTileText = "Show Less";
        }
        else {
            this.accountTileList = this.accountRemnantTileList; // show less tles
            this.showMoreLessAccountTileText = "Show More";
        }
    }

    showMoreOrLessClick() {
        this._cacheService.currentlyShowingLessAccountTiles = !this._cacheService.currentlyShowingLessAccountTiles;
        this.showMoreOrLessTiles();
    }

    load() {
        var initIndex;
        if (this._cacheService.accountTileList) {
            this.accountRemnantTileList = this._cacheService.accountTileList.slice(0, 4);
            this.showMoreOrLessTiles();
            this.isTapEnabled = this._cacheService.overviewJson.response.accounts[0].accountContainer.tapEnabled;
            this.tapChargeAmount = this._cacheService.overviewJson.response.accounts[0].accountContainer.tapChargeAmount;
            this.isrestricted = this._cacheService.overviewJson.response.accounts[0].accountContainer.albrestricted;
            this.isPlanRestricted = this._cacheService.overviewJson.response.accounts[0].accountContainer.apprestricted;

        }


        if (this._cacheService.accountPlanSummaryList) {
            this.planSummaryList = this._cacheService.accountPlanSummaryList.planList;
            for (var i = 0; i < this.planSummaryList.length; i++) {
                if (this.planSummaryList[i].currentPlan) {
                    this.planClick = i;
                    initIndex = i;
                }
            }

            if (this.planSummaryList[initIndex].planCharge)
                this.selectedCost.planCharge = this.planSummaryList[initIndex].planCharge;
            this._interactionService.statusPlan(this.selectedCost);

            let isdefault = this._cacheService.accountPlanSummaryList.defaultProduct;
            let defaultPlan = isdefault ? 'multiple' : 'single';
            this.switchAccount(defaultPlan);
        }

        if (this._cacheService.linePlanSummaryList) {
            this.showSingleLinePlans = true;
        }


        this.lineSummaryList = this._cacheService.lineSummaryList;

        if (this.lineSummaryList && this.lineSummaryList.length > 0) {
            this.totalDueToday = this.lineSummaryList
                .map(line => {
                    return (line.currentLineCharges.dueToday.price.value) ? Number(line.currentLineCharges.dueToday.price.value) : 0;
                })
                .reduce((current, next) => {
                    return current + next;
                });
        }

        if (this._cacheService.productVOList) {
            this.showAccessory = true;
        }
        if (this._cacheService.proposedCharges) {
            this.accessoryPrice = this._cacheService.proposedCharges.accessoryCharge.price.formattedPrice;
        }
    }

    handlePlanChange(plan, ind) {
        this.planClick = ind;
        this.selectedPlan = plan;
        if (plan.planCharge > this.planSummaryList[2].planCharge) {
            this.selectedCost.planColor = "rgb(205, 4, 11)";
            this.selectedCost.planStatusIcon = "fa fa-caret-up pull-right";
        } else if (plan.planCharge == this.planSummaryList[2].planCharge) {
            this.selectedCost.planColor = "black";
            this.selectedCost.planStatusIcon = "";
        } else {
            this.selectedCost.planColor = "#82CEAC";
            this.selectedCost.planStatusIcon = "fa fa-caret-down pull-right";
        }

        this.selectedCost.planCharge = plan.planCharge;
    }

    switchAccount(from) {
        if (from == 'single') {
            if (this._cacheService.linePlanSummaryList.planList)
                this.planSummaryList = this._cacheService.linePlanSummaryList.planList;
        } else if (from == 'multiple') {
            this.planSummaryList = this._cacheService.accountPlanSummaryList.planList;

        }
    }

    showInfo(event) {
        if (this.isPlanRestricted == true) {
            this.msgs = [];
            this.msgs.push({ severity: 'error', summary: 'Notification', detail: 'Account is Resctricted' });
        }
    }

    tileClick() {

        //this.tileClicked = this.tileClicked? false: true;
        this._cacheService.currentlyHidingAccountTilesDiv = !this._cacheService.currentlyHidingAccountTilesDiv;

    }
    getAccountTileDivButtonStyle() {
        if (this._cacheService.currentlyHidingAccountTilesDiv)
            return "fa fa-minus-square-o fa-lg";
        else
            return "fa fa-plus-square-o fa-lg";
    }

    selAccessory()
    {
        this.router.navigate(['/accessories-app']);

        let menuItem:MenuItem = {
            routerLink: '/accessories-app'
        };
        this._interactionService.publishMenuItem(menuItem);
    }


    resetLine(selectedLine: LineSummaryList)
    {
        let lineDevice: LineDevice = {
            mld: selectedLine.mldSequence,
            resetAction: 'DEVICE',
        };
        let req: DeviceRequest = {
            action: 'reset',
            inputData: [lineDevice],
        };
        this.showSpinner(true);
        this._deviceService.deviceChange(req).
            subscribe((json) =>
            {
                try
                {
                    let linesMetadata = this.lineSummaryList.map(line => {
                        return {
                            mtn: line.mtn,
                            isModified: (selectedLine.mtn === line.mtn)? false : line.isModified,
                            isResetEnabled: (selectedLine.mtn === line.mtn)? false : line.isResetEnabled,
                            isNewLine: line.isNewLine,
                            selectedUpgradeOption: line.selectedUpgradeOption,
                        };
                    });

                    let lineSummaryList = json.response.lineContainer.lineSummaryList;
                    lineSummaryList = lineSummaryList.map(line => {
                        let currentLineMetadata = linesMetadata.find(lineMetadata => {
                            if(lineMetadata.mtn === line.mtn) return true;
                        });
                        if(currentLineMetadata)
                        {
                            line.isModified = currentLineMetadata.isModified;
                            line.isResetEnabled = currentLineMetadata.isResetEnabled;
                            line.isNewLine = currentLineMetadata.isNewLine;
                            line.selectedUpgradeOption = currentLineMetadata.selectedUpgradeOption;
                        }
                        return line;
                    });


                    this.lineSummaryList = lineSummaryList;
                    this._cacheService.lineSummaryList = lineSummaryList;

                    let comparisonContainer = json.response.comparisonContainer;
                    this._cacheService.comparisonContainer = comparisonContainer;
                    this._interactionService.publishComparisonContainer(comparisonContainer);

                    this.showSpinner(false);
                }
                catch (error)
                {
                    console.log(error);

                    this.msgs = [];
                    this.msgs.push({
                        severity: 'error',
                        summary: 'Service is unavailable, please try again.',
                        detail: error
                    });
                    this.showSpinner(false);
                }
            },
            error => {
                console.log(error);
                this.showSpinner(false);
            });
    }

    buyout(selectedLine: LineSummaryList)
    {
        let lineDevice: LineDevice = {
            mld: selectedLine.mldSequence,
            buyoutAmt: selectedLine.buyoutAmount.price.value,
        };
        let req: DeviceRequest = {
            action: 'buyout',
            inputData: [lineDevice],
        };
        this.showSpinner(true);
        this._deviceService.deviceChange(req).
            subscribe((json) =>
            {
                try
                {
                    let linesMetadata = this.lineSummaryList.map(line => {
                        return {
                            mtn: line.mtn,
                            isModified: line.isModified,
                            isResetEnabled: (selectedLine.mtn === line.mtn)? false : line.isResetEnabled,
                            isNewLine: line.isNewLine,
                            selectedUpgradeOption: line.selectedUpgradeOption,
                        };
                    });

                    let lineSummaryList = json.response.lineContainer.lineSummaryList;
                    lineSummaryList = lineSummaryList.map(line => {
                        let currentLineMetadata = linesMetadata.find(lineMetadata => {
                            if(lineMetadata.mtn === line.mtn) return true;
                        });
                        if(currentLineMetadata)
                        {
                            line.isModified = currentLineMetadata.isModified;
                            line.isResetEnabled = currentLineMetadata.isResetEnabled;
                            line.isNewLine = currentLineMetadata.isNewLine;
                            line.selectedUpgradeOption = currentLineMetadata.selectedUpgradeOption;
                        }
                        return line;
                    });


                    this.lineSummaryList = lineSummaryList;
                    this._cacheService.lineSummaryList = lineSummaryList;

                    let comparisonContainer = json.response.comparisonContainer;
                    this._cacheService.comparisonContainer = comparisonContainer;
                    this._interactionService.publishComparisonContainer(comparisonContainer);

                    this.showSpinner(false);
                }
                catch (error)
                {
                    console.log(error);

                    this.msgs = [];
                    this.msgs.push({
                        severity: 'error',
                        summary: 'Service is unavailable, please try again.',
                        detail: error
                    });
                    this.showSpinner(false);
                }
            },
            error => {
                console.log(error);
                this.showSpinner(false);
            });
    }


     updateTap(isChecked: boolean) {
         this.showSpinner(true);
         if (!this.isTapProcessing) {
             this.isTapProcessing = true;
             console.log('isChecked for TAP Update -- ' + isChecked);

             let action = "drop";
             if(isChecked){
                 action = "add";
             }

             this._overviewAppService.updateTap(action).subscribe((jsonResp) => {
                 console.log("TAP Update Listener !!");

                let overviewJson: OverviewRoot = jsonResp;
                let lineSummaryList: LineSummaryList[] = overviewJson.response.accounts[0].deviceContainer.lineSummaryList;
                let comparisonContainer: ComparisonContainer = overviewJson.response.accounts[0].comparisonContainer;

                this._cacheService.comparisonContainer = comparisonContainer;
                this._interactionService.publishComparisonContainer(comparisonContainer);
                this._cacheService.comparisonContainer.proposedCharges.isupdated = true;
                
                this._cacheService.overviewJson.response.accounts[0].accountContainer.tapEnabled = overviewJson.response.accounts[0].accountContainer.tapEnabled;
                this.isTapEnabled = this._cacheService.overviewJson.response.accounts[0].accountContainer.tapEnabled;

               // Update this._cacheService.lineSummaryList to update values for updated lines only
                if (lineSummaryList){
                   for(var i = 0; i < lineSummaryList.length; i++){
                       for(var j = 0; j < this._cacheService.lineSummaryList.length; j++){
                           if (lineSummaryList[i].deviceId == this._cacheService.lineSummaryList[j].deviceId){
                               console.log('updating Device - '+this._cacheService.lineSummaryList[j].deviceId);
                               this._cacheService.lineSummaryList[j] = lineSummaryList[i];
                           }
                       }
                   }
                    this._interactionService.publishLineSummary(lineSummaryList);
                }


                 this.isTapProcessing = false;
                 this.showSpinner(false);
             },
                 error => {
                     this.isTapProcessing = false;
                     this.showSpinner(false);
                     console.log("error in updateTap !!" + error);
                 });
         }
        }

    private showSpinner(show: boolean)
    {
        SpinnerUtils.showSpinner('#main-menu-tabs', show);
    }

    private clearToolTips()
    {
                for(var i=0; i<this._cacheService.lineSummaryList.length; i++)
        {
            this._cacheService.lineSummaryList[i].showToolTip = false;
        }
    }
    private clearToolTipsAll(line: LineSummaryList)
    {
        for(var i=0; i<this._cacheService.lineSummaryList.length; i++)
        {
            this._cacheService.lineSummaryList[i].showToolTip = false;
        }

        line.showToolTip = !line.showToolTip;
    }

}
