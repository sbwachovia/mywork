import { StateCacheService } from './../../shared/services/data-interaction/state-cache.service';
import { Component, Input, OnInit, Output, EventEmitter, ElementRef, ViewChild, Renderer } from '@angular/core';
import {Router} from "@angular/router";
import {MenuItem} from "../../shared/components/tab-menu/tab-menu.component";
import {InteractionService} from "../../shared/services/data-interaction/interaction-service";
import {LineSummaryList} from "../../shared/models/overview-app-model";



@Component({
    selector: 'overview-lineSummary',
    templateUrl: './overview-lineSummary.component.html',
    styleUrls: ['./overview-lineSummary.component.css']
    //changeDetection: ChangeDetectionStrategy.OnPush
})

export class OverviewLineSummaryComponent implements OnInit
{
    @ViewChild('w_cus-tooltip') el:ElementRef;
    @Input() line: LineSummaryList;
    showPricingToolTip: boolean = false;
    showEligible: boolean = false;
    showDp: boolean = false;
    

    @Output() buyout: EventEmitter<LineSummaryList> = new EventEmitter<LineSummaryList>();
    @Output() reset: EventEmitter<LineSummaryList> = new EventEmitter<LineSummaryList>();
    @Output() clearToolTips: EventEmitter<LineSummaryList> = new EventEmitter<LineSummaryList>();

    CanDisplayToolTip(line: LineSummaryList, toolTipType:string)
    {
        return (line.showToolTip && (line.toolTipType === toolTipType));
    }

    handleToolTip(line: LineSummaryList, event: Event, toolTipType:string )
    {
        console.log("the tooltip=" + toolTipType );
        line.toolTipType = toolTipType;
        this.clearToolTips.emit(line);

        event.stopPropagation();

        // this.showPricingToolTip = !this.showPricingToolTip;
        // //this.rd.invokeElementMethod(this.el.nativeElement,'focus');
        // if(this.showPricingToolTip)
        // {
        //     this.rd.setElementAttribute(this.el.nativeElement, 'display', 'block');
        // }
        // else
        // {
        //     this.rd.setElementAttribute(this.el.nativeElement, 'display', 'none');
        // }
        
    }

    constructor(
        private router: Router,
        private interactionService: InteractionService,
        private stateCacheService: StateCacheService,
        private rd: Renderer
    ){
    }

    ngOnInit()
    {
        console.log("inside the constrctor...");
    }

    onUpgrade(line: LineSummaryList, upgradeOption: string)
    {
        line.selectedUpgradeOption = upgradeOption;
        this.router.navigate(['/device-app', {mtn: line.mtn, lineActionType: line.selectedUpgradeOption}]);

        let menuItem:MenuItem = {
            routerLink: '/device-app'
        };
        this.interactionService.publishMenuItem(menuItem);
    }

    onBuyout()
    {
        if(this.line)
        {
            this.buyout.emit(this.line);
        }
    }

    onReset()
    {
        if(this.line)
        {
            this.reset.emit(this.line);
        }
    }
    valid(val){
        val.value = val.value.replace(/[^0-9.]/g, '');
    }
}
