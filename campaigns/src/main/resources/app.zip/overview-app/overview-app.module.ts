import { NgModule } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { OverlayPanelModule } from "primeng/components/overlaypanel/overlaypanel";
import {GrowlModule} from 'primeng/primeng';

import { OverviewAppComponent } from "./overview-app.component";
import { OverviewAccountTileComponent } from "./overview-accountTile/overview-accountTile.component";
import { OverviewPlanSummaryComponent } from "./overview-planSummary/overview-planSummary.component";
import { OverviewLineSummaryComponent } from "./overview-lineSummary/overview-lineSummary.component";
import { OverviewAccessoryComponent } from "./overview-accessories/overview-accessory.component";



const moduleRoutes: Routes = [
    {
        path: '',
        component: OverviewAppComponent
    },
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        OverlayPanelModule,
        RouterModule.forChild(moduleRoutes),
        GrowlModule
    ],
    declarations: [
        OverviewAppComponent,
        OverviewAccountTileComponent,
        OverviewPlanSummaryComponent,
        OverviewLineSummaryComponent,
        OverviewAccessoryComponent
    ],
    providers: [],
})
export class OverviewAppModule {

}
