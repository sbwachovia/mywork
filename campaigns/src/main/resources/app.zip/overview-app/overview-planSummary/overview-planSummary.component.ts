import {Component, Input, OnInit} from '@angular/core';
import {InteractionService} from "../../shared/services/data-interaction/interaction-service";
import {OverviewAppService} from "../../shared/services/Overview/overview-app.service";
import {StateCacheService} from "../../shared/services/data-interaction/state-cache.service";
import {OverviewRoot, OverviewAccountVO, LineSummaryList, OverviewPlanVO, ComparisonContainer} from "../../shared/models/overview-app-model";




@Component({
    selector: 'overview-planSummary',
    templateUrl: './overview-planSummary.component.html'
})
export class OverviewPlanSummaryComponent implements OnInit
{
    selectedPlan
    plan: any = {'border': '1px solid red'}
    @Input() planSummary;
    @Input() planChecked;
    planNameChar: string;

    constructor(private interactionService: InteractionService,
                private _overviewAppService: OverviewAppService,
                private _cacheService: StateCacheService,) {}

    clickListener(plan: OverviewPlanVO)
    {
        //this._overviewAppService.updatePlan("plan="+plan.planId);
         //this.interactionService.publishPlan(plan);

         this._overviewAppService.updatePlan("planSorId="+plan.planId)
            .subscribe((jsonResp) => {
                console.log("In Plans clickListener !!");

                let overviewJson: OverviewRoot = jsonResp;
                let lineSummaryList: LineSummaryList[] = overviewJson.response.accounts[0].deviceContainer.lineSummaryList;                                   
                let comparisonContainer: ComparisonContainer = overviewJson.response.accounts[0].comparisonContainer;

                this._cacheService.comparisonContainer = comparisonContainer;
                this.interactionService.publishComparisonContainer(comparisonContainer);
                 this._cacheService.comparisonContainer.proposedCharges.isupdated = true;
                

               // Update this._cacheService.lineSummaryList to update values for updated lines only
                if (lineSummaryList){
                   for(var i = 0; i < lineSummaryList.length; i++){
                       for(var j = 0; j < this._cacheService.lineSummaryList.length; j++){
                           if (lineSummaryList[i].deviceId == this._cacheService.lineSummaryList[j].deviceId){
                               console.log('updating Device'+this._cacheService.lineSummaryList[j].deviceId);
                               this._cacheService.lineSummaryList[j] = lineSummaryList[i];
                           }
                       }
                   }
                    //this._cacheService.lineSummaryList = lineSummaryList;
                    this.interactionService.publishLineSummary(lineSummaryList);
                }



            },
            error => {
                console.log(error);
                console.log("error in clickListener !!"+ error);
                //this.errorMessage = "error is: " + error;

            });
    }

    ngOnInit() {
        this.planNameChar = this.planSummary.imageName.charAt(0);
    }

}
