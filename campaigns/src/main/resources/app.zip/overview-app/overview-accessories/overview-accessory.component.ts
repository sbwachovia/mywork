import { Component, Input } from "@angular/core";
import { Router } from "@angular/router";
import { InteractionService } from "../../shared/services/data-interaction/interaction-service";
import { MenuItem } from "../../shared/components/tab-menu/tab-menu.component";
import { StateCacheService } from "../../shared/services/data-interaction/state-cache.service";
import {ProductVOList, ChildSkus} from "../../shared/models/accessories-app-model";



@Component({
    selector: 'overview-accessory',
    templateUrl: './overview-accessory.component.html'
})
export class OverviewAccessoryComponent {
    @Input() accessory:ProductVOList;
    counter:number = 0;
    selSku: ChildSkus;

    constructor(
        private router: Router,
        private interactionService: InteractionService,
        private _cacheService: StateCacheService
    ) {
        
    }

    onload() {
        console.log("Overview Accessory : ", this.accessory.childSkus[0].brand);
    }

    selAccessory() {

        this.router.navigate(['/accessories-app']);

        let menuItem: MenuItem = {
            routerLink: '/accessories-app'
        };
        this.interactionService.publishMenuItem(menuItem);
    }

   

}
