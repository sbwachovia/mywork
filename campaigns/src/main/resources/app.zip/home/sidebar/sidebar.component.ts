import { ProceedToOrderRootObject } from './../../shared/models/app-models';
import { Component, OnDestroy, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import { Subscription } from "rxjs";
import { InteractionService } from "../../shared/services/data-interaction/interaction-service";
import {CurrentCharges, ProposedCharges, ComparisonContainer} from '../../shared/models/overview-app-model';
import {StateCacheService} from "../../shared/services/data-interaction/state-cache.service";
import {OverviewAppService} from "../../shared/services/Overview/overview-app.service";
import {AppComponent} from "../../app.component";



@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html'
})
export class AppSidebarComponent implements OnDestroy, OnInit
{
    display: boolean = false;
    subscription: Subscription;
    comparisonContainer: ComparisonContainer;
    currentCharges: ProposedCharges;
    quoteCharges: ProposedCharges;
    show: boolean = false;
    nbsDisplay: boolean = false;
    emailDisplay:boolean = false;

    constructor(
        private _cacheService: StateCacheService,
        private _interactionService: InteractionService,
        private _overviewAppService: OverviewAppService,
        private router: Router,
        private _appComponent: AppComponent
    )
    {
        this.subscription = _interactionService.comparisonContainerSubject$.subscribe(comparisonContainer => {
            this.load();
        });
    }

    ngOnInit()
    {

    }

    load()
    {
        console.log('In Sidebar load...');
        this.comparisonContainer = this._cacheService.comparisonContainer;
        if (this.comparisonContainer.existingCharges){
            this.currentCharges = this.comparisonContainer.existingCharges;
        }
        this.quoteCharges = this.comparisonContainer.proposedCharges;
        //console.log('!!!!In load'+ this.quoteCharges.accessoryCharge);
    }



    reset() {
        this._overviewAppService.resetQuote()
            .subscribe((jsonResp) => {
                console.log("In reset !!" + jsonResp);

                //this._interactionService.clearAllCache;
                this._cacheService.accountTileList = null;
                this._cacheService.linePlanSummaryList = null;
                this._cacheService.accountPlanSummaryList = null;
                this._cacheService.lineSummaryList = null;
                this._cacheService.comparisonContainer = null;
                this._cacheService.plans = null;

                this._appComponent.initServiceCalls();
                this.router.navigate(['/overview-app', {}]);
            },
            error => {
                console.log(error);
                console.log("error in reset !!" + error);
            });

    }



    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    showNBSDisplay(){
        this.nbsDisplay = true;
    }
    showEmailDisplay(){
        this.emailDisplay = true;
    }

    proceedToOrder()
    {
        let quoteRequest = {
            action: 'CONVERT_TO_ORDER',
        };
        this._overviewAppService.fetchQuoteDetails(quoteRequest)
            .subscribe((quoteResp: ProceedToOrderRootObject) => {
                 console.log("Proceed response: =" + JSON.stringify(quoteResp));
                console.log("Proceed response: cartId=" + quoteResp.response.cartId);

                let queryParams = 'pageName=iconic&action=orderReview&sourceSystem=ONEPOS&source=flexSharedCart';
                if(quoteResp)
                {
                    queryParams += '&cartId=' + quoteResp.response.cartId + '&quoteId=' + quoteResp.response.cartId;
                }
                else {
                    queryParams += '&cartId=null&quoteId=null';
                }

                let url = '/telesales/common/netaceContainer.jsp?' + queryParams;

                let winParams = 'toolbar=yes,scrollbars=yes,resizable=yes,top=50,left=100,width=1000,height=800';
                let orderWin = window.open(url, 'Order', winParams);
            },
            error => {
                console.log(error);
            });
    }

}
