import {Input, OnInit, OnDestroy} from '@angular/core';
import { Component } from '@angular/core';
import { Subscription } from "rxjs";
import { InteractionService } from "../../shared/services/data-interaction/interaction-service";
import { StateCacheService } from "../../shared/services/data-interaction/state-cache.service";
import { ProposedCharges } from '../../shared/models/overview-app-model';



@Component({
    selector: 'app-header',
    templateUrl: './app-header.component.html'
})
export class AppHeaderComponent implements OnInit, OnDestroy
{
    @Input() isLoading: boolean;
    quoteCharges: ProposedCharges;
    subscription: Subscription;
    loadingSubscription: Subscription
    isLoading2: boolean = true;

    customerName: string;
    repName: string;
    dueToday: string;


    constructor(
        private _cacheService: StateCacheService,
        private _interactionService: InteractionService)
    {
        this.subscription = _interactionService.comparisonContainerSubject$.subscribe(comparisonContainer => {
            this.quoteCharges = this._cacheService.comparisonContainer.proposedCharges;
        });

        this.loadingSubscription = _interactionService.loadingSubject$.subscribe(status => {
            this.isLoading2 = status;
            if(status == true)
            {
                this.customerName = "...";
                this.dueToday = "..."
            }
            else {
                this.customerName = "???";
                this.dueToday = "???";
            }
        });
    }

    ngOnInit()
    {
        this.repName = this._cacheService.transitionQueryParams.uswin;
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
        this.loadingSubscription.unsubscribe();
    }

}
