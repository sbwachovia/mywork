import {Component, OnInit, OnDestroy} from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {Subscription} from 'rxjs';
import { Message } from 'primeng/primeng';
import {MenuItem} from './shared/components/tab-menu/tab-menu.component';
import {OverviewRoot, OverviewAccountVO, LineSummaryList, OverviewPlanVO,ProductPlanList, ComparisonContainer, PlanContainer} from './shared/models/overview-app-model';
import {InteractionService} from './shared/services/data-interaction/interaction-service';
import {OverviewAppService} from './shared/services/Overview/overview-app.service';
import {StateCacheService} from './shared/services/data-interaction/state-cache.service';
import { ErrorHandlingService } from './shared/services/error-handling/error-handling.service';
import {TransitionQueryParams} from './shared/models/app-models';
import {URLSearchParams} from '@angular/http';


@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy
{
    private menuItems: MenuItem[];
    private sub: Subscription;

    private errorMessage: string;
    private isLoading: boolean = true;
    msgs: Message[] = [];


    constructor(
        private route:ActivatedRoute,
        private router:Router,
        private _overviewAppService: OverviewAppService,
        private _cacheService: StateCacheService,
        private _interactionService: InteractionService,
        private _errorHandlingService: ErrorHandlingService
    ){

        //let rawParams:string = window.location.search;
        let rawParams:string = localStorage.getItem('quoteParams');
        console.log('RAW query params rceived: ' + rawParams);
        if(!rawParams)
            rawParams = '';
        
        //rawParams = rawParams.substr(1); //remove leading char "?"
        let params = new URLSearchParams(rawParams);
    
        let transitionQueryParams:TransitionQueryParams =
        {
            env:params.get('env'),
            uswin:params.get('uswin'),
            salesRepid:params.get('salesRepid'),
            location:params.get('location'),
            mtn:params.get('mtn')
        }
        console.log('Final query params: ' + JSON.stringify(transitionQueryParams));
        this._cacheService.transitionQueryParams = transitionQueryParams;


        // this.sub = this.route.queryParams.subscribe((params: Params) => {
        //     let transitionQueryParams:TransitionQueryParams =
        //     {
        //         env:params['env'],
        //         uswin:params['uswin'],
        //         salesRepid:params['salesRepid'],
        //         location:params['location'],
        //         mtn:params['mtn']
        //     }

        //     this._cacheService.transitionQueryParams = transitionQueryParams;

        // });
    }

    ngOnInit() {
        this.initMenuItems();
        this.initServiceCalls();

        this._errorHandlingService.errorMessageSubject$
                                  .subscribe(errorMsg => {
                                    this.msgs = [];
                                    this.msgs.push({ severity: 'error', summary: errorMsg, detail: '' });
                                  });
    }

    retryLoad()
    {
       this.router.navigate(['']);
    }
    initMenuItems()
    {
        this.menuItems = [
            {label: 'Overview', routerLink: ['/overview-app'], active: true},
            {label: 'Device', routerLink: ['/device-app']},
            {label: 'Plan', routerLink: ['/plan-app']},
            {label: 'Accessory', routerLink: ['/accessories-app']},
            {label: 'Trade-In', routerLink: ['/tradein-app']},
        ];
    }

    initServiceCalls()
    {
        this.showLoadingIcon(true);

        let mtn = this._cacheService.transitionQueryParams.mtn;
        mtn = (mtn)? mtn: '8013884930';

        let overviewRequest = {
            mtn: mtn,
        };
        this._overviewAppService.fetchAccountSummary(overviewRequest)
            .subscribe((jsonResp) => {

                let overviewJson: OverviewRoot = jsonResp;

                if(!overviewJson
                    || !overviewJson.response
                    || !overviewJson.response.accounts)
                {
                    alert('No Overview JSON response!');
                    return;
                }

                let accountTileList: OverviewAccountVO[] = overviewJson.response.accounts[0].accountContainer.accountSummary.accountTileList;
                let planContainer: PlanContainer = overviewJson.response.accounts[0].planContainer;
                let lineSummaryList: LineSummaryList[] = overviewJson.response.accounts[0].deviceContainer.lineSummaryList;
                let comparisonContainer: ComparisonContainer = overviewJson.response.accounts[0].comparisonContainer;

                if (planContainer) {
                    let currentPlanSummaryList: OverviewPlanVO = planContainer.currentPlanDetails;
                    let multiLinePlanSummaryList: ProductPlanList = this.getProdutList(planContainer, 'plan2880001');//planContainer.productPlanList[0];
                    let singleLinePlanSummaryList: ProductPlanList = this.getProdutList(planContainer, 'plan3440001');//planContainer.productPlanList[1];


                    if (multiLinePlanSummaryList) {
                        // TODO: Remove this change after sort is implemented in service
                        multiLinePlanSummaryList = this.sortPlans(multiLinePlanSummaryList);
                        // if there is no current plan in the list then add current plan to the list to be displayed as first element
                        if (!this.hasCurrentPlan(multiLinePlanSummaryList)) {
                            multiLinePlanSummaryList.planList.splice(0, 0, currentPlanSummaryList);
                        }
                        this._cacheService.accountPlanSummaryList = multiLinePlanSummaryList;
                    }


                    if (singleLinePlanSummaryList) {
                        //  use this.getProdutList(planContainer, 'plan3440001')
                        if (!this.hasCurrentPlan(singleLinePlanSummaryList))
                            singleLinePlanSummaryList.planList.splice(0, 0, currentPlanSummaryList);
                        this._cacheService.linePlanSummaryList = singleLinePlanSummaryList;
                    }

                }
                // Set overview models in cache serive
                this._cacheService.overviewJson = overviewJson;
                this._cacheService.accountTileList = accountTileList;
                this._cacheService.lineSummaryList = lineSummaryList;
                this._cacheService.comparisonContainer = comparisonContainer;


                this._interactionService.publishOverviewRoot(overviewJson);
                this._interactionService.publishComparisonContainer(comparisonContainer);


                this.showLoadingIcon(false);
            },
            error => {
                console.log(error);
                this.showLoadingIcon(false);
                this.errorMessage = error;
            });
    }

    ngOnDestroy()
    {
        this.sub.unsubscribe();
    }


    private getProdutList(planContainer: PlanContainer, productId: String): ProductPlanList {
        for (var i = 0; i < planContainer.productPlanList.length; i++) {
            if (planContainer.productPlanList[i].productId == productId)
                return planContainer.productPlanList[i]
        }
        return null;
    }


    private hasCurrentPlan(planSummaryList: ProductPlanList): boolean {
        let planList = planSummaryList.planList;
        for (var i = 0; i < planList.length; i++){
            if(planList[i].currentPlan == true){
                return true;
            }
        }
        return false;
    }


    private sortPlans(accountPlanSummaryList: ProductPlanList): ProductPlanList {
        accountPlanSummaryList.planList.sort((plan1, plan2) => {

            let plan1ImageName: any = plan1.imageName;
            let plan2ImageName: any = plan2.imageName;

            plan1ImageName = plan1ImageName.substring(0, 1);
            plan2ImageName = plan2ImageName.substring(0, 1);


            if (plan1ImageName === 'S')
                plan1ImageName = 0;
            if (plan1ImageName === 'M')
                plan1ImageName = 1;
            if (plan1ImageName === 'L')
                plan1ImageName = 2;
            if (plan1ImageName === 'U')
                plan1ImageName = 3;

            if (plan2ImageName === 'S')
                plan2ImageName = 0;
            if (plan2ImageName === 'M')
                plan2ImageName = 1;
            if (plan2ImageName === 'L')
                plan2ImageName = 2;
            if (plan2ImageName === 'U')
                plan2ImageName = 3;



            if (plan1ImageName < plan2ImageName) return -1;
            if (plan1ImageName > plan2ImageName) return 1;
            return 0;
        });
        return accountPlanSummaryList;
    }





    /**
     *  Spinner.
     */
    private blinkerTimerId = null;
    private showLoadingIcon(show: boolean)
    {
        this.isLoading = show;
        this._interactionService.publishLoading(this.isLoading);

        let progressbar = <HTMLDivElement>document.querySelector('.progressbar');
        if (show)
        {
            progressbar.style.height = screen.height+ 'px';
            progressbar.querySelector('span').style.lineHeight = screen.height+ 'px';
            this.blinkerTimerId = setInterval(function()
            {
                var dotElms = progressbar.querySelectorAll('.dot');
                for(var i=0; i < dotElms.length; i++)
                {
                    dotElms[i].classList.toggle('grey');
                }
            }, 200);

            progressbar.style.display = 'block';
        }
        else
        {
            if(this.blinkerTimerId)
            {
                clearInterval(this.blinkerTimerId);
            }
            progressbar.style.display = 'none';
        }
    }

}

