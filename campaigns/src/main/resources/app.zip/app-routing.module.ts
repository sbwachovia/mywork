import { NgModule } from '@angular/core';
import { RouterModule, Routes } from "@angular/router";

import { PageNotFoundComponent } from "./home/exception/not-found.component";



const appRoutes: Routes = [
    {
        path: 'overview-app',
        loadChildren: 'app/overview-app/overview-app.module#OverviewAppModule'
    },
    {
        path: 'device-app',
        loadChildren: 'app/device-app/device-app.module#DeviceAppModule'
    },
    {
        path: 'plan-app',
        loadChildren: 'app/plan-app/plan-app.module#PlanAppModule'
    },
    {
        path: 'accessories-app',
        loadChildren: 'app/accessories-app/accessories-app.module#AccessoriesAppModule'
    },
    {
        path: 'tradein-app',
        loadChildren: 'app/tradein-app/tradein-app.module#TradeinAppModule'
    },
    {
        path: 'recycle-app',
        loadChildren: 'app/recycle-app/recycle-app.module#RecycleAppModule'
    },
    {
        path: '',
        redirectTo: '/overview-app',
        pathMatch: 'full'
    },
    {
        path: '**',
        component: PageNotFoundComponent
    }
];

@NgModule({
    imports: [ RouterModule.forRoot(appRoutes) ],
    exports: [ RouterModule ]
})
export class AppRoutingModule {}
